import cardHeaderImg from "@/assets/stories/diagnostic-image.jpg";
import { RichText } from "@/components/RichText/RichText";
import { Stack } from "@/components/Stack/Stack";
import { Typography } from "@/components/Typography/Typography";

import { IconLink } from "../IconLink";
import styles from "./Card.module.scss";
import { ImageWithTooltip } from "../ImageWithTooltip/ImageWithTooltip";
import { SVGAdd } from "../SVGIcon/static/SVGAdd";

export const HEADING_AND_TAGS_AND_PLUS_CIRCLE = () => (
  <Stack spacing="least">
    <Stack direction="column" spacing="xs">
      <Typography variant="s1">
        UPGRADED LEXUS LX FLAGSHIP SUV OFFERS CUSTOMERS EVEN GREATER CHOICE, CAPABILITY AND
        TECHNOLOGY
      </Typography>

      <Stack component="ul" spacing="even-less">
        <li>
          <Typography variant="l2">News</Typography>
        </li>
        <li>
          <Typography variant="l2">Lexus Electrified</Typography>
        </li>
        <li>
          <Typography variant="l2">Partnerships</Typography>
        </li>
      </Stack>
    </Stack>

    <div className={styles.roundedBorder}>
      <SVGAdd height={16} width={16} />
    </div>
  </Stack>
);

export const TEXT_AND_HEADING_NO_ICON_LINK = (extraText = "") => (
  <Stack direction="column" spacing="xs">
    <Typography variant="s1">PLATINUM ELECTRIFIED BENEFITS</Typography>
    <RichText
      html={`<p>Dissolving the boundary between exterior and interior, the UX offers a wider field of vision so you can enjoy where the road takes you. Exquisite hand-crafted ornamentation and thoughtful touches anticipate your desire for exceptional comfort and detail. ${extraText}</p`}
    />
  </Stack>
);

export const TEXT_AND_HEADING_WITH_ICON_LINK = (extraText = "") => (
  <>
    {TEXT_AND_HEADING_NO_ICON_LINK(extraText)}
    <IconLink href="#" variant="spaced">
      book now
    </IconLink>
  </>
);

export const TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL = (
  <>
    <Stack direction="column" spacing="xs">
      <Typography variant="s1">A NEW KIND OF CROSSOVER</Typography>
      <RichText
        html={`<p>Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation.</p>`}
      />
    </Stack>
    <IconLink href="#" variant="spaced">
      book now
    </IconLink>
  </>
);

export const CARD_IMAGE_HEADER = (
  <img
    src={cardHeaderImg}
    alt={"Card header image"}
    style={{ width: "100%", maxWidth: "100%", objectFit: "contain" }}
  />
);

export const CARD_IMAGE_HEADER_WITH_TOOLTIP = (key = "") => (
  <ImageWithTooltip
    aspectRatio={1}
    isPopupFixed
    portraitImageTooltipDescription={`tooltip description ${key}`}
    isNormalContainer={true}
  >
    <ImageWithTooltip.PortraitImage>{CARD_IMAGE_HEADER}</ImageWithTooltip.PortraitImage>
  </ImageWithTooltip>
);
