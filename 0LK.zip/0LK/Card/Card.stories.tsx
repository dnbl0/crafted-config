import { Meta, StoryObj } from "@storybook/react";

import {
  CARD_IMAGE_HEADER,
  HEADING_AND_TAGS_AND_PLUS_CIRCLE,
  TEXT_AND_HEADING_WITH_ICON_LINK,
  TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL,
} from "@/components/Card/Card.stories.data";
import {
  CardPaddings,
  CardLayouts,
  CardProps,
  CardTopPaddings,
} from "@/components/Card/Card.types";
import { ImageWithTooltip } from "@/components/ImageWithTooltip/ImageWithTooltip";
import { JustifyContentValue } from "@/components/types";
import { DemoSlot } from "@/stories/presentation/DemoSlot";
import { TupleUnion } from "@/types/helpers";

import { Card } from "./Card";
import { CardType } from "./CardTop";

type CardStoryArgs = {
  background: CardType;
  paddingTop?: CardTopPaddings;
  footerText?: string | JSX.Element;
  noDefaultDecorator: boolean;
} & CardProps;

const meta = {
  title: "layouts/Card",
  component: Card,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=6898-61516&m=dev",
    },
  },
  decorators: [
    (Story, context) =>
      context.args.noDefaultDecorator ? (
        <Story />
      ) : (
        <div style={{ width: 320 }}>
          <Story />
        </div>
      ),
  ],
  argTypes: {
    background: {
      options: [
        "topElevate",
        "topEncore",
        "topPlatinum",
        "topElectrified",
        "topClear",
      ] satisfies TupleUnion<CardType>,
      control: { type: "select" },
      description: "Background color for the card header",
    },
    footerText: {
      control: { type: "text" },
      description: "Footer text for the card component",
    },
    noBackground: {
      control: { type: "boolean" },
      description: "Remove background color of card",
    },
    noHorizontalGap: {
      control: { type: "boolean" },
      description: "Remove the default gap in horizontal layout.",
    },
    padding: {
      control: { type: "select" },
      options: ["default", "small", "medium", "minimal"] satisfies TupleUnion<CardPaddings>,
      description: "Content Padding",
    },
    paddingTop: {
      control: { type: "select" },
      options: ["default", "none"] satisfies TupleUnion<CardTopPaddings>,
      description: "Top Padding",
    },
    layout: {
      control: { type: "select" },
      options: ["vertical", "horizontal", "auto"] satisfies TupleUnion<CardLayouts>,
      description: "Layout directions of items inside. Default is vertical",
    },
    justifyContent: {
      control: { type: "select" },
      options: [
        "flex-start",
        "center",
        "flex-end",
        "space-between",
        "space-around",
        "space-evenly",
      ] satisfies TupleUnion<JustifyContentValue>,
      description: "Sets the `justifyContent` CSS property for the children content.",
    },
  },
  args: {
    background: undefined,
    footerText: "footer content",
    noBackground: false,
    noHorizontalGap: false,
    padding: "default",
    paddingTop: "default",
    layout: "vertical",
    noDefaultDecorator: false,
    justifyContent: undefined,
  },
} as Meta<CardStoryArgs>;

export default meta;

type Story = StoryObj<CardStoryArgs>;

export const Default: Story = {
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        <DemoSlot />
      </Card.Top>

      <Card.Footer>{args.footerText || <DemoSlot />}</Card.Footer>

      <DemoSlot />
    </Card>
  ),
};

export const CardWithoutHeader: Story = {
  render: (args) => (
    <Card {...args}>
      <Card.Footer>{args.footerText || <DemoSlot />}</Card.Footer>

      <DemoSlot />
    </Card>
  ),
};

export const CardWithoutContent: Story = {
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        <DemoSlot />
      </Card.Top>

      <Card.Footer>{args.footerText || <DemoSlot />}</Card.Footer>
    </Card>
  ),
};

export const CardWithoutFooter: Story = {
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        <DemoSlot />
      </Card.Top>

      <DemoSlot />
    </Card>
  ),
};

export const Horizontal: Story = {
  args: {
    layout: "horizontal",
    noDefaultDecorator: true,
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        <DemoSlot />
      </Card.Top>
      <DemoSlot />
      <Card.Footer>{args.footerText || <DemoSlot />}</Card.Footer>

      <DemoSlot />
    </Card>
  ),
};

export const Auto: Story = {
  args: {
    layout: "auto",
    noDefaultDecorator: true,
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        <DemoSlot />
      </Card.Top>
      <DemoSlot />
      <DemoSlot />
      <Card.Footer>{args.footerText || <DemoSlot />}</Card.Footer>
    </Card>
  ),
};

export const CardWithImageHeaderVariantMinimalNoBackground: Story = {
  args: {
    noBackground: true,
    padding: "minimal",
    paddingTop: "none",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top padding={args.paddingTop}>{CARD_IMAGE_HEADER}</Card.Top>
      {TEXT_AND_HEADING_WITH_ICON_LINK()}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 410 }}>
        <Story />
      </div>
    ),
  ],
};

export const CardWithImageHeaderVariantSmallNoBackground: Story = {
  args: {
    noBackground: true,
    padding: "small",
    paddingTop: "none",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK()}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 410 }}>
        <Story />
      </div>
    ),
  ],
};

export const CardWithImageHeaderNoBackgroundHorizontal: Story = {
  args: {
    noBackground: true,
    padding: "small",
    paddingTop: "none",
    layout: "horizontal",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 752, height: 332 }}>
        <Story />
      </div>
    ),
  ],
};

export const CardWithImageHeaderNoBackgroundHorizontalNoGap: Story = {
  args: {
    noBackground: true,
    noHorizontalGap: true,
    paddingTop: "none",
    layout: "horizontal",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 752, height: 332 }}>
        <Story />
      </div>
    ),
  ],
};

export const CardWithImageHeaderVariantSmallNoBackgroundAutoMobile: Story = {
  args: {
    noBackground: true,
    padding: "small",
    paddingTop: "none",
    layout: "auto",
    noDefaultDecorator: true,
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL}
    </Card>
  ),
  parameters: {
    viewport: {
      defaultViewport: "mobile",
      defaultOrientation: "landscape",
    },
  },
};

export const CardWithImageHeaderVariantSmallNoBackgroundAutoMobilePortrait: Story = {
  args: {
    noBackground: true,
    padding: "small",
    paddingTop: "none",
    layout: "auto",
    noDefaultDecorator: true,
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL}
    </Card>
  ),
  parameters: {
    viewport: {
      defaultViewport: "mobile",
    },
  },
};

export const CardWithImageHeaderVariantSmallNoBackgroundAuto: Story = {
  args: {
    noBackground: true,
    padding: "small",
    paddingTop: "none",
    layout: "auto",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top {...args} padding={args.paddingTop}>
        {CARD_IMAGE_HEADER}
      </Card.Top>

      {TEXT_AND_HEADING_WITH_ICON_LINK_HORIZONTAL}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 410 }}>
        <Story />
      </div>
    ),
  ],
};

export const CardWithImageHeaderAndPlusIcon: Story = {
  args: {
    padding: "medium",
    paddingTop: "none",
  },
  render: (args) => (
    <Card {...args}>
      <Card.Top padding={args.paddingTop}>
        <ImageWithTooltip
          landscapeImageTooltipDescription="Tooltip description"
          toolTipPosition="topLeft"
        >
          <ImageWithTooltip.LandscapeImage>{CARD_IMAGE_HEADER}</ImageWithTooltip.LandscapeImage>
        </ImageWithTooltip>
      </Card.Top>
      {HEADING_AND_TAGS_AND_PLUS_CIRCLE()}
    </Card>
  ),
  decorators: [
    (Story) => (
      <div style={{ width: 410 }}>
        <Story />
      </div>
    ),
  ],
};
