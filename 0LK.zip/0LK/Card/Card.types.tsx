import { JustifyContentValue } from "@/components/types";

/** @deprecated */
export const CARD_WITH_HEADER_PADDINGS = ["default", "small", "minimal"] as const;
/** @deprecated */
export type CardWithHeaderPaddings = "default" | "small" | "minimal";
/** @deprecated */
export const CARD_WITH_HEADER_TOP_PADDINGS = ["default", "none"] as const;
/** @deprecated */
export type CardWithHeaderTopPaddings = "default" | "none";
/** @deprecated */
export const CARD_WITH_HEADER_LAYOUTS = ["vertical", "horizontal", "auto"] as const;
/** @deprecated */
export type CardWithHeaderLayouts = "vertical" | "horizontal" | "auto";

export type CardPaddings = "default" | "medium" | "small" | "minimal";
export type CardTopPaddings = "default" | "none";
export type CardLayouts = "vertical" | "horizontal" | "auto";

export type CardProps = {
  /**
   * Default is has vertical and horizontal paddings, small and minimal only horizontal padding.
   */
  padding?: CardPaddings;
  /**
   * Layout directions of items inside. Default is vertical.
   */
  layout?: CardLayouts;
  /*
   * Remove the default background color.
   */
  noBackground?: boolean;
  /*
   * Remove the default gap in horizontal layout.
   */
  noHorizontalGap?: boolean;
  /**
   * Sets the `justifyContent` CSS property for the children content.
   */
  justifyContent?: JustifyContentValue;
  /**
   * Set className, default is empty.
   */
  className?: string;
  /**
   * Set className for content, default is empty.
   */
  classNameContent?: string;
};
