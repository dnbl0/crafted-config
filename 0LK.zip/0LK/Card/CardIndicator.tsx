import { Typography } from "@/components/Typography/Typography";

export const CardIndicator: React.FC<React.PropsWithChildren> = ({ children }) => {
  return <Typography variant="c1">{children}</Typography>;
};
