import { Meta, StoryFn } from "@storybook/react";
import { useRef, useState } from "react";

import { ContentBlock } from "@/components/ContentBlock/ContentBlock";
import { ContentBlockInnerContainer } from "@/components/ContentBlockInnerContainer/ContentBlockInnerContainer";
import { keyThemeAndSizeModes } from "@/stories/parameters/modes";
import { DemoInvisibleElementWrapper } from "@/stories/presentation/DemoInvisibleElementWrapper";
import { DemoSlot } from "@/stories/presentation/DemoSlot";

import { Carousel, CarouselRef } from "./Carousel";

const meta = {
  title: "layouts/Carousel",
  component: Carousel,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/file/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=6468-22239&t=whQlsHDRxW9lRH0u-4",
    },
    chromatic: {
      modes: keyThemeAndSizeModes,
    },
  },
  argTypes: {
    loop: {
      control: { type: "boolean" },
    },
    initialItem: { control: { type: "number" } },
  },
  args: {
    label: "Carousel slide content",
    loop: false,
    initialItem: 1,
  },
  decorators: [
    (Story) => (
      <ContentBlock container="outer">
        <ContentBlockInnerContainer width="12col">
          <Story />
        </ContentBlockInnerContainer>
      </ContentBlock>
    ),
  ],
} satisfies Meta<typeof Carousel>;

export default meta;

type Story = StoryFn<typeof Carousel>;

const AllChildren = (tallItem = -1) =>
  [...Array(6).keys()].map((item) => (
    <DemoInvisibleElementWrapper fullHeight key={item}>
      <DemoSlot height={tallItem === item ? "100px" : undefined} />
    </DemoInvisibleElementWrapper>
  ));

export const Default: Story = (args) => <Carousel {...args}>{AllChildren(1)}</Carousel>;

export const CarouselWithIndicatorsAndLoop: Story = (args) => {
  const carouselRef = useRef<CarouselRef>(null);
  const [currentItem, setCurrentItem] = useState(1);

  const next = () => {
    carouselRef.current && carouselRef.current.next();
  };

  const prev = () => {
    carouselRef.current && carouselRef.current.prev();
  };
  return (
    <>
      <Carousel {...args} ref={carouselRef} onItemChange={setCurrentItem}>
        {AllChildren(4)}
      </Carousel>
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
        <button onClick={() => prev()} style={{ marginRight: "10px", fontSize: "50px" }}>
          &lt;{" "}
        </button>
        <p>Current Item: {currentItem}</p>
        <button onClick={() => next()} style={{ marginLeft: "10px", fontSize: "50px" }}>
          {" "}
          &gt;
        </button>
      </div>
    </>
  );
};
