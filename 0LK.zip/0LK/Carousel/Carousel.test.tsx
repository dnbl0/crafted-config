/* eslint-disable @typescript-eslint/no-empty-function */
import { composeStory } from "@storybook/react";
import "@testing-library/jest-dom";
import { render } from "@testing-library/react";
import { createElement } from "react";

import Meta, {
  Default as DefaultStory,
  CarouselWithIndicatorsAndLoop as CarouselWithIndicatorsAndLoopStory,
} from "./Carousel.stories";

const stories = [DefaultStory, CarouselWithIndicatorsAndLoopStory] as const;

const kinds = stories.map((story) => composeStory(story, Meta));

class ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}

describe("Carousel layout", () => {
  window.ResizeObserver = ResizeObserver;
  Element.prototype.scrollTo = () => {};

  it("Renders all kinds", () => {
    for (const kind of kinds) {
      const { container } = render(createElement(kind));
      // Targeting Content Block Inner Container first
      const carousel = container.querySelector(".container div.carousel");
      expect(carousel).not.toBeNull();
      expect(carousel).toBeInTheDocument();
      expect(carousel).toHaveAttribute("aria-label", "Carousel slide content");
      const slides = (carousel as HTMLElement)?.children;
      expect(slides).toHaveLength(6);
    }
  });
});
