import cn from "classnames";
import debounce from "lodash/debounce";
import {
  Children,
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";

import styles from "./Carousel.module.scss";
import {
  isInsideInteractiveElement,
  isPrimaryMouseClick,
  getCustomCssProps,
} from "./Carousel.utils";

type CarouselProps = React.PropsWithChildren<{
  /**
   * The aria label for the carousel. If not provided, the default is "Carousel slide content".
   */
  label?: string;
  /**
   * Whether the carousel should loop back to the beginning when it reaches the end. Default is false.
   */
  loop?: boolean;
  /**
   * The initial item of the carousel. Default is 1.
   */
  initialItem?: number;

  /*
   * The number of items to display in the container. Default is 2.
   */
  noOfVisibleItems?: number;

  /**
   *
   * Callback function that is called when the item of the carousel changes.
   */
  onItemChange?: (item: number) => void;

  /**
   *
   * Callback function that is called when the item of the carousel changes.
   */
  onScrollableChange?: (isScrollable: boolean) => void;
}>;

export interface CarouselRef {
  /**
   * Go to the specified item.
   */
  goTo: (item: number) => void;
  /**
   *  Go to the next item.
   */
  next: () => void;
  /**
   * Go to the previous item.
   */
  prev: () => void;
}

const debouncedHandleScrollTime = 150;

const useMouseHandlers = (
  loop: boolean,
  childrenMapRef: React.RefObject<Map<number, HTMLDivElement>>,
  sliderRef: React.RefObject<HTMLDivElement>
) => {
  const startX = useRef<number | null>(null);
  const scrollLeft = useRef<number | null>(null);
  const isDown = useRef<boolean>(false);
  const distanceRef = useRef<number | null>(null);
  const willLoop = useRef<boolean>(true);
  const isCarouselStart = useRef<boolean>(false);
  const isCarouselEnd = useRef<boolean>(false);
  const prevStart = useRef<boolean>(false);
  const prevEnd = useRef<boolean>(false);
  const childrenMap = childrenMapRef.current;

  const onMouseDown = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      /** Only allow interactions if the left mouse button is pressed and no modifier keys (Alt, Ctrl, Meta) are held.
       * Prevents unintended behavior from right/middle clicks or when using keyboard shortcuts. */
      if (!isPrimaryMouseClick(e) || isInsideInteractiveElement(e.target)) {
        return; // Exit early if not a primary click or clicking inside an interactive element
      }
      const slider = sliderRef.current;
      isDown.current = true; // is mouse down
      if (!slider) return;
      slider.classList.add(styles.dragging);
      startX.current = e.pageX - slider.offsetLeft; // get mouse position relative to carousel
      scrollLeft.current = slider.scrollLeft;
    },
    [sliderRef]
  );

  const onMouseUp = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!isPrimaryMouseClick(e) || isInsideInteractiveElement(e.target)) {
        return; // Exit early if not a primary click or clicking inside an interactive element
      }
      if (!distanceRef) return;
      isDown.current = false;
      const isStart = isCarouselStart.current; // start of carousel
      const isEnd = isCarouselEnd.current; // end of carousel
      const isPrevStart = prevStart.current;
      const isPrevEnd = prevEnd.current;
      const slider = sliderRef.current;

      if (!slider) return;
      e.preventDefault();
      slider.classList.remove(styles.dragging);

      /** Check if we are at edge of carousel */
      if ((isStart || isEnd) && childrenMap && loop) {
        if (willLoop.current) {
          if (isEnd) {
            /** if previously at start of carousel then don't loop */
            if (isPrevStart) {
              prevStart.current = false;
              prevEnd.current = true;
              return;
            }
            sliderRef.current.scrollTo({ left: 0 });
            willLoop.current = true;
            prevStart.current = true;
            return;
          }

          if (isStart) {
            if (isPrevEnd) {
              prevStart.current = true;
              prevEnd.current = false;
              return;
            }
            sliderRef.current.scrollTo({ left: childrenMap.get(childrenMap.size)?.offsetLeft });
            willLoop.current = true;
            prevEnd.current = true;

            return;
          }
        }
      }
    },
    [childrenMap, loop, sliderRef]
  );

  const onMouseMove = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!isDown.current) return;
      const slider = sliderRef.current;
      const startXRef = startX.current;
      const scrollLeftRef = scrollLeft.current;

      if (!slider || scrollLeftRef === null || startXRef === null) return;
      const x = e.pageX - slider.offsetLeft;
      /** distance between first and last mouse move */
      const distance = x - startXRef;
      distanceRef.current = distance;
      /** adjust carousel scroll position based on distance traveled */
      slider.scrollLeft = scrollLeftRef - distance;

      isCarouselStart.current = sliderRef.current.scrollLeft === 0;
      isCarouselEnd.current =
        sliderRef.current.scrollLeft + sliderRef.current.clientWidth >=
        sliderRef.current.scrollWidth;
    },
    [sliderRef]
  );

  const onMouseLeave = useCallback(() => {
    const slider = sliderRef.current;
    if (!slider) return;
    slider.classList.remove(styles.dragging);
    isDown.current = false;
  }, [sliderRef]);

  return {
    onMouseDown,
    onMouseUp,
    onMouseLeave,
    onMouseMove,
  };
};

const useCarouselControls = (
  sliderRef: React.MutableRefObject<HTMLDivElement | null>,
  childrenMapRef: React.MutableRefObject<Map<number, HTMLDivElement>>,
  carouselRef: React.ForwardedRef<CarouselRef>,
  setCurrentItem: (item: number) => void,
  loop: boolean
) => {
  const childrenMap = childrenMapRef.current;

  const getNextFocusChild = useCallback(
    (isBack?: boolean) => {
      const slider = sliderRef.current;
      let closestIndex = -1;
      if (!childrenMap || !slider) return -1;
      /** find next focus item based on direction */
      if (isBack) {
        for (const [index, item] of [...childrenMap].reverse()) {
          const itemRect = item.getBoundingClientRect();
          if (itemRect.left + itemRect.width < slider.offsetWidth / 2) {
            closestIndex = index;
            break;
          }
        }
      } else {
        for (const [index, item] of childrenMap) {
          const itemRect = item.getBoundingClientRect();
          if (itemRect.left > slider.offsetWidth / 2) {
            closestIndex = index;
            break;
          }
        }
      }
      return closestIndex;
    },
    [childrenMap, sliderRef]
  );

  const scrollToItem = useCallback(
    (child: HTMLElement) => {
      const slider = sliderRef.current;
      if (!slider) return;
      slider.scrollTo({
        left: child.offsetLeft + child.offsetWidth / 2 - slider.clientWidth / 2,
        behavior: "smooth",
      });
    },
    [sliderRef]
  );

  const goTo = useCallback(
    (item: number) => {
      const targetChild = childrenMap.get(item);
      targetChild && scrollToItem(targetChild);
      setCurrentItem(item);
    },
    [childrenMap, scrollToItem, setCurrentItem]
  );

  const next = useCallback(() => {
    const slider = sliderRef.current;
    if (!slider) return;
    const isEndScroll = slider.scrollLeft + slider.clientWidth >= slider.scrollWidth;
    if (loop && isEndScroll) {
      return goTo(1);
    }
    const next = getNextFocusChild();
    goTo(next);
  }, [getNextFocusChild, goTo, loop, sliderRef]);

  const prev = useCallback(() => {
    const slider = sliderRef.current;
    if (!slider || !childrenMap) return;
    const isStartScroll = slider.scrollLeft === 0;
    if (loop && isStartScroll) {
      return goTo(childrenMap.size);
    }
    const prev = getNextFocusChild(true);
    goTo(prev);
  }, [childrenMap, getNextFocusChild, goTo, loop, sliderRef]);

  useImperativeHandle(carouselRef, () => ({
    goTo,
    next,
    prev,
  }));

  return {
    goTo,
    next,
    prev,
  };
};

type ChildWrapperProps = {
  noOfVisibleItems: number;
  index: number;
  children: React.ReactNode;
  currentItem: number;
  customCSSProperties?: React.CSSProperties;
  resizeObserverRef: React.MutableRefObject<ResizeObserver | null>;
  childrenMapRef: React.MutableRefObject<Map<number, HTMLDivElement>>;
};

const ChildWrapper: React.FC<ChildWrapperProps> = ({
  noOfVisibleItems,
  customCSSProperties,
  index,
  childrenMapRef,
  resizeObserverRef,
  children,
}) => {
  const setRef = useCallback(
    (el: HTMLDivElement | null) => {
      const item = index + 1;
      if (el) {
        childrenMapRef.current.set(item, el);
        resizeObserverRef.current?.observe(el);
      } else {
        const child = childrenMapRef.current.get(item);
        child && resizeObserverRef.current?.unobserve(child);
        childrenMapRef.current.delete(item);
      }
    },
    [childrenMapRef, index, resizeObserverRef]
  );

  return (
    <div
      className={cn(styles.slide, { [styles.minWidthSmall]: noOfVisibleItems > 3 })}
      style={customCSSProperties}
      ref={setRef}
      role="group"
      aria-roledescription="slide"
    >
      {children}
    </div>
  );
};

/**
 * Carousel displays a series of child elements in a horizontally scrollable container,
 * with support for touch and mouse dragging interactions and keyboard navigation.
 * It uses `forwardRef` to allows it to accept a ref prop that can be used to access the
 * component's internal methods (goTo, next, and prev, see example below).
 * These methods allow external components to control the carousel's current slide.
 *
 * The carousel use human friendly item selection, first item is 1 and last item is the
 * total number of items.
 *
 * Carousel will render items to the size of nearest CSS container (or page). However,
 * left and right items will be aligned to current left and right edges of the given
 * parent space (So when you scroll tiles will go out of normal boundaries).
 *
 * It is recommended to have it wrapped in `ContentBlock` with `container="outer"` property.
 *
 * Usage:
 *
 * ```tsx
 * <ContentBlock container="outer">
 *  <ContentBlockInnerContainer>
 *    <Carousel>{children}</Carousel>
 *  </ContentBlockInnerContainer>
 * </ContentBlock>
 * ```
 *
 * ## State
 * ### Uncontrolled
 * A Carousel's `current slide` will initially display the first item, uncontrolled,
 * and `current slide item` will update with scrolling interactions.
 *
 * ```tsx
 * <Carousel>{children}</Carousel>
 * ```
 *
 * ### Controlled
 * The `initialItem` prop can be used to make the `current slide` controlled.
 * The `onItemChange` event is fired when the user edits the initialItem,
 * and receives the new `item`.
 *
 * ```tsx
 * const [currentItem, setCurrentItem] = useState(0);
 * <Carousel initialItem={currentItem} onItemChange={setCurrentItem} />
 * ```
 */
const Carousel = /*#__PURE__*/ (function () {
  const Carousel = forwardRef<CarouselRef, CarouselProps>(
    (
      {
        children,
        loop = false,
        label = "Carousel slide content",
        initialItem = 1,
        noOfVisibleItems = 2,
        onItemChange,
        onScrollableChange,
      },
      ref
    ) => {
      const sliderRef = useRef<HTMLDivElement | null>(null);
      const isScrollableRef = useRef<boolean>(true);
      const childrenMapRef = useRef<Map<number, HTMLDivElement>>(new Map());
      const [currentItem, setCurrentItem] = useState<number>(initialItem);
      const customCSSProperties = getCustomCssProps(noOfVisibleItems);
      const resizeObserverRef = useRef<ResizeObserver | null>(null);

      const { goTo } = useCarouselControls(sliderRef, childrenMapRef, ref, setCurrentItem, loop);
      const { onMouseDown, onMouseLeave, onMouseUp, onMouseMove } = useMouseHandlers(
        loop,
        childrenMapRef,
        sliderRef
      );

      useEffect(() => {
        goTo(currentItem);
      }, [goTo, currentItem]);

      const getCurrentFocusChild = () => {
        const childrenMap = childrenMapRef.current;
        const slider = sliderRef.current;
        let closestIndex = -1;
        let closestDistance = Infinity;
        if (!childrenMap || !slider) return -1;
        /** find current centered item based on their position */
        childrenMap.forEach((item, index) => {
          const itemRect = item.getBoundingClientRect();
          const itemCenter = itemRect.left + itemRect.width / 2;

          const distance = Math.abs(itemCenter - slider.offsetWidth / 2);
          if (distance < closestDistance) {
            closestDistance = distance;
            closestIndex = index;
          }
        });
        return closestIndex;
      };

      const debouncedHandleScroll = useRef(
        debounce((target) => {
          if (target instanceof HTMLDivElement) {
            const isCarouselEnd = target.scrollLeft + target.clientWidth >= target.scrollWidth;
            const isCarouselStart = target.scrollLeft === 0;
            if (isCarouselStart) {
              setCurrentItem(1);
              return onItemChange?.(1);
            } else if (isCarouselEnd) {
              setCurrentItem(childrenMapRef.current.size);
              return onItemChange?.(childrenMapRef.current.size);
            }
            /** jump to current centered item in carousel after scroll */
            const currentFocusChild = getCurrentFocusChild();
            setCurrentItem(currentFocusChild);
            onItemChange?.(currentFocusChild);
          }
        }, debouncedHandleScrollTime)
      ).current;

      const handleScroll = useCallback(
        (event: React.UIEvent<HTMLDivElement>) => {
          const target = event.target;
          debouncedHandleScroll(target);
        },
        [debouncedHandleScroll]
      );

      useEffect(() => {
        return () => {
          debouncedHandleScroll.cancel();
        };
      }, [debouncedHandleScroll]);

      useEffect(() => {
        /** when resize, determine if carousel is scrollable or not */
        resizeObserverRef.current = new ResizeObserver(() => {
          const slider = sliderRef.current;
          if (!slider) return;
          const prevIsScrollableRef = isScrollableRef.current;
          const scrollWidth = slider.scrollWidth || undefined;
          const carouselWidth = slider.clientWidth || undefined;

          if (scrollWidth && carouselWidth && scrollWidth > carouselWidth) {
            isScrollableRef.current = true;
          } else {
            isScrollableRef.current = false;
          }

          prevIsScrollableRef !== isScrollableRef.current &&
            onScrollableChange?.(isScrollableRef.current);
        });

        sliderRef.current && resizeObserverRef.current.observe(sliderRef.current);

        /** need to attach observer after first render because ResizeObserver is not available on component mount */
        childrenMapRef.current.forEach((el) => resizeObserverRef.current?.observe(el));

        return () => resizeObserverRef.current?.disconnect();
      }, [onScrollableChange]);

      return (
        <div
          className={styles.carousel}
          aria-label={label}
          ref={sliderRef}
          role="group"
          aria-roledescription={label}
          tabIndex={0}
          onMouseUp={onMouseUp}
          onMouseMove={onMouseMove}
          onMouseLeave={onMouseLeave}
          onMouseDown={onMouseDown}
          onScroll={handleScroll}
        >
          {Children.map(children, (child, index) => (
            <ChildWrapper
              currentItem={currentItem}
              customCSSProperties={customCSSProperties}
              noOfVisibleItems={noOfVisibleItems}
              index={index}
              childrenMapRef={childrenMapRef}
              resizeObserverRef={resizeObserverRef}
            >
              {child}
            </ChildWrapper>
          ))}
        </div>
      );
    }
  );
  Carousel.displayName = "Carousel";
  return Carousel;
})();

export { Carousel };
