import { Meta, StoryFn } from "@storybook/react";

import { ThemeCanvas, ThemeVariant } from "@/theming/themingTypes";
import { TupleUnion } from "@/types/helpers";

import { ContentBlock, ContentBlockPadding } from "./ContentBlock";

export default {
  title: "Layouts/Content Block",
  component: ContentBlock,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/file/a45Y8haw7B34SQ5apG3Jzl/OSB-%26-SLC-(Delivery)?type=design&node-id=8371-28868&mode=design&t=WkwJYEAOjlv5uMj1-4",
    },
    backgrounds: { disable: true },
  },
  argTypes: {
    variant: {
      control: { type: "select" },
      options: ["default", "alt"] satisfies ThemeVariant[],
      mapping: ["default", "alt"] satisfies ThemeVariant[],
    },
    canvas: {
      control: { type: "select" },
      options: ["default", "lighter", "darker"] satisfies TupleUnion<ThemeCanvas>,
      mapping: ["default", "lighter", "darker"] satisfies TupleUnion<ThemeCanvas>,
    },
    p: {
      control: { type: "select" },
      options: ["none", "more", "default", "less"] satisfies TupleUnion<ContentBlockPadding>,
      mapping: ["none", "more", "default", "less"] satisfies TupleUnion<ContentBlockPadding>,
    },
  },
} satisfies Meta<typeof ContentBlock>;

const Template: StoryFn<typeof ContentBlock> = (args) => <ContentBlock {...args} />;

const children = (
  <div style={{ backgroundColor: "grey", width: "100%" }}>
    Children will be here. <br />
    <br />
    <br />
    This takes constraint space for content
  </div>
);

const compareFontSizeComponents = (
  <>
    <div style={{ position: "relative" }}>
      <span>Text to compare different font sizes</span>
      <img
        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAAJUlEQVRIS2M85S05k2EAAeOoA0ZDYDQERkNgNARGQ2A0BAY6BADgdxyBin0x4gAAAABJRU5ErkJggg=="
        alt=""
        style={{ position: "absolute", top: 0, left: 0 }}
      />
    </div>
    <div>
      This is a long paragraph <span style={{ fontSize: "1rem" }}>1rem</span>{" "}
      <span style={{ fontSize: "1em" }}>1em</span> <span style={{ fontSize: "16px" }}>16px</span>{" "}
      More text for children to test long text. A long paragraph to test different browser text
      accessibility. More text for children to test long text. A long paragraph to test different
      browser text accessibility. More text for children to test long text. A long paragraph to test
      different browser text accessibility. More text for children to test long text. A long
      paragraph to test different browser text accessibility.More text for children to test long
      text. A long paragraph to test different browser text accessibility.
      <div style={{ height: "100vh" }}></div>
      This text can be visible only after scrolling.
    </div>
  </>
);

export const DefaultContentBlock = Template.bind({});
DefaultContentBlock.args = {
  variant: "default",
  canvas: "default",
  p: "default",
  children,
};

export const CompareFontSizesContentBlock = Template.bind({});
CompareFontSizesContentBlock.args = {
  variant: "default",
  canvas: "default",
  p: "default",
  children: compareFontSizeComponents,
};

export const AltContentBlock = Template.bind({});
AltContentBlock.args = {
  variant: "alt",
  canvas: "default",
  p: "default",
  children,
};

export const NoPaddingContentBlock = Template.bind({});
NoPaddingContentBlock.args = {
  variant: "default",
  canvas: "default",
  p: "none",
  children,
};

export const MorePaddingContentBlock = Template.bind({});
MorePaddingContentBlock.args = {
  variant: "default",
  canvas: "default",
  p: "more",
  children,
};

export const LessPaddingContentBlock = Template.bind({});
LessPaddingContentBlock.args = {
  variant: "default",
  canvas: "default",
  p: "less",
  children,
};

export const SectionContentBlock = Template.bind({});
SectionContentBlock.args = {
  component: "section",
  variant: "default",
  canvas: "default",
  p: "default",
  children,
};

export const AsideContentBlock = Template.bind({});
AsideContentBlock.args = {
  component: "aside",
  variant: "default",
  canvas: "default",
  p: "default",
  children,
};
