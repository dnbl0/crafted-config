import { composeStory } from "@storybook/react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import { createElement } from "react";

import { ContentBlock } from "./ContentBlock";
import Meta, {
  DefaultContentBlock,
  AltContentBlock,
  NoPaddingContentBlock,
  MorePaddingContentBlock,
  LessPaddingContentBlock,
} from "./ContentBlock.stories";

const stories = {
  DefaultContentBlock,
  AltContentBlock,
  NoPaddingContentBlock,
  MorePaddingContentBlock,
  LessPaddingContentBlock,
};

const kinds = Object.entries(stories).map(([name, storyData]) => ({
  name,
  story: composeStory(storyData, Meta),
}));

describe("ContentBlock", () => {
  it.each(kinds)("Renders $name", ({ story }) => {
    const { container } = render(createElement(story));
    const contentBlock = container.querySelector("div");
    expect(contentBlock).toBeVisible();
  });

  it("Renders a div by default", () => {
    render(<ContentBlock>mock-content</ContentBlock>);
    const contentBlockTagName = screen
      .getByText("mock-content")
      .parentElement?.tagName.toLowerCase();

    expect(contentBlockTagName).toBe("div");
  });

  it.each(["div", "section", "aside"] as const)(
    "When `component` is %s it renders a %s",
    (component) => {
      render(<ContentBlock component={component}>mock-content</ContentBlock>);
      const contentBlockTagName = screen
        .getByText("mock-content")
        .parentElement?.tagName.toLowerCase();

      expect(contentBlockTagName).toBe(component);
    }
  );
});
