import cn from "classnames";

import { HeadingLevelProvider } from "@/components/HeadingProvider/HeadingProvider";
import { getSurfaceProps } from "@/components/Surface/Surface";
import { ThemeVariantScope } from "@/components/ThemeVariantScope/ThemeVariantScope";
import { ThemeSurfaceShade, ThemeVariant } from "@/theming/themingTypes";

import styles from "./ContentBlock.module.scss";

export type ContentBlockPadding = "none" | "more" | "default" | "less";

export type ContentBlockContainer = "inner" | "outer";

type ContentBlockProps = React.PropsWithChildren<{
  /**
   * ContentBlock padding. This is automatically managed by DLS tokens
   * to switch between desktop and mobile.
   * Default: `"default"`.
   */
  p?: ContentBlockPadding;

  /**
   * Theme variant which should be established as context.
   * Default: `"default"`.
   */
  variant?: ThemeVariant;

  /**
   * Canvas defines section background color.
   * Default: `"default"`.
   */
  canvas?: ThemeSurfaceShade;

  /**
   * If set section will provide a CSS **inline** container scope named `section`.
   * `inner` will provide a container inside the section, so it will exclude padding.
   * `outer` will provide a container outside the section, so it will include padding and
   * will be equal to 100% occupied space.
   *
   * Default: `undefined`.
   *
   * Child components may target this container to apply specific styles.
   * To use units like `cqw` in your child components you need to ensure that there is no
   * other CSS container defined between your component and ContentBlock.
   */
  container?: ContentBlockContainer;

  /**
   * Class name(s) to customise component if required.
   */
  className?: string;

  /**
   * Define the semantic element of the ContentBlock by setting the `component`. An `aside`
   * will have a default `role` of `complimentary` and should be used when the content is only
   * indirectly related to the document's main content, e.g. sidebars or call-out boxes.
   *
   * Default: `"div"`.
   */
  component?: "div" | "section" | "aside";
}>;

/**
 * ContentBlock component is a starting point for building page layout.
 * ContentBlock is designed to be used with ContentBlockInnerContainer, but
 * can be used without it.
 *
 * ContentBlock defines current contextual Variant and specifies background
 * color (canvas).
 *
 * NOTE 1: ContentBlock will apply CSS `contain` property set to `content` to
 * isolate and optimize content rendering. This will block any `absolute`
 * or `fixed` positioned elements from rendering outside of the section
 * boundaries defined by static content.
 *
 * NOTE 2: ContentBlock provides public CSS custom props which could be used
 * by child components to apply specific styles. These are:
 * --lk-c-section-padding-v - applied vertical padding
 * --lk-c-section-padding-h - applied horizontal padding
 * --lk-c-section-gap - applied gap between child elements
 */
export const ContentBlock: React.FC<ContentBlockProps> = ({
  className,
  component: Component = "div",
  variant = "default",
  canvas = "default",
  p = "default",
  container,
  children,
}) => {
  let increaseLevel = false;
  if (Component === "section" || Component === "aside") {
    increaseLevel = true;
  }

  return (
    <HeadingLevelProvider shouldIncreaseHeadingLevel={increaseLevel}>
      <ThemeVariantScope variant={variant}>
        {(variantClassName) => (
          <Component
            className={cn(
              styles.contentBlock,
              getSurfaceProps("canvas", canvas).className,
              styles[`${p}Padding`],
              variantClassName,
              className,
              { [styles[`container`]]: container === "outer" }
            )}
          >
            <div
              className={cn(styles.contentBlockBox, {
                [styles[`container`]]: container === "inner",
              })}
            >
              {children}
            </div>
          </Component>
        )}
      </ThemeVariantScope>
    </HeadingLevelProvider>
  );
};
