import { Meta, StoryFn } from "@storybook/react";

import { ContentBlock } from "@/components/ContentBlock/ContentBlock";
import { DemoSlot } from "@/stories/presentation/DemoSlot";

import {
  ContentBlockInnerContainer,
  ContentBlockInnerContainerWidth,
} from "./ContentBlockInnerContainer";

export default {
  title: "Layouts/Content Block Inner Container",
  component: ContentBlockInnerContainer,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=7854-6070&t=inSGafM1upo1kX2x-1",
    },
    backgrounds: { disable: true },
  },
  argTypes: {
    width: {
      control: { type: "select" },
      options: [
        "full",
        "6col",
        "8col",
        "10col",
        "12col",
      ] satisfies ContentBlockInnerContainerWidth[],
      mapping: [
        "full",
        "6col",
        "8col",
        "10col",
        "12col",
      ] satisfies ContentBlockInnerContainerWidth[],
    },
  },
} satisfies Meta<typeof ContentBlockInnerContainer>;

const Template: StoryFn<typeof ContentBlockInnerContainer> = (args) => (
  <ContentBlock>
    <ContentBlockInnerContainer {...args} />
  </ContentBlock>
);

const children = <DemoSlot />;

export const WithFullWidth = Template.bind({});
WithFullWidth.args = {
  width: "full",
  children,
};

export const With12colWidth = Template.bind({});
With12colWidth.args = {
  width: "12col",
  children,
};

export const With10colWidth = Template.bind({});
With10colWidth.args = {
  width: "10col",
  children,
};

export const With8colWidth = Template.bind({});
With8colWidth.args = {
  width: "8col",
  children,
};

export const With6colWidth = Template.bind({});

With6colWidth.args = {
  width: "6col",
  children,
};
