import { composeStory } from "@storybook/react";
import "@testing-library/jest-dom";
import { render } from "@testing-library/react";
import { createElement } from "react";

import Meta, {
  With12colWidth,
  With8colWidth,
  With6colWidth,
  WithFullWidth,
} from "./ContentBlockInnerContainer.stories";

const stories = {
  With12colWidth,
  With8colWidth,
  With6colWidth,
  WithFullWidth,
};

const kinds = Object.entries(stories).map(([name, storyData]) => ({
  name,
  story: composeStory(storyData, Meta),
}));

describe("ContentBlockInnerContainer", () => {
  it.each(kinds)("Renders $name", ({ story }) => {
    const { container } = render(createElement(story));
    const directChildDiv = container.querySelector("div.container");
    expect(directChildDiv).toBeVisible();
  });
});
