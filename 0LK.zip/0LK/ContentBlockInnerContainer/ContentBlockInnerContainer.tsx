import styles from "./ContentBlockInnerContainer.module.scss";
import { Container } from "../Container/Container";

export type ContentBlockInnerContainerWidth = "full" | "6col" | "8col" | "10col" | "12col";

type ContentBlockInnerContainerProps = React.PropsWithChildren<
  React.HTMLAttributes<HTMLDivElement> & {
    /**
     * Width limitation for inner content.
     */
    width?: ContentBlockInnerContainerWidth;

    /**
     * Class name(s) to customise component if required.
     */
    className?: string;

    /**
     * Ref to inner Container `div` element.
     */
    divRef?: React.Ref<HTMLDivElement>;
  }
>;

/**
 * Content Block Inner Container is a component which is designed to apply certain
 * constraints on inner content. It limits maximum content width and ensures that
 * content always fit to the screen size without horizontal scrolling effects.
 *
 * ContentBlockInnerContainer is based on `Container`, which is based on `div` element and supports
 * all default attributes for `div` element. (className will be merged with internal classes)
 *
 * Usage:
 *
 * ```tsx
 * import { ContentBlock, ContentBlockInnerContainer } from "lexus-kit";
 * ...
 * <ContentBlock>
 *  <ContentBlockInnerContainer width="6col" role="...">
 *   <h1>I'm content in a narrow block!</h1>
 *  </ContentBlockInnerContainer>
 * </ContentBlock>
 * ```
 */
export const ContentBlockInnerContainer: React.FC<ContentBlockInnerContainerProps> = ({
  width = "12col",
  children,
  divRef,
  ...rest
}) => (
  <Container
    maxWidth={width === "full" ? "none" : width}
    {...rest}
    divRef={divRef}
    className={styles.fullWidthContainer}
  >
    {children}
  </Container>
);
