import { Meta, StoryObj } from "@storybook/react";

import { TupleUnion } from "@/types/helpers";

import { Divider, DividerVariant } from ".";

const meta = {
  title: "Components/Divider",
  component: Divider,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=11054-111800&node-type=frame&t=e1AV5CRl2k92diQ2-0",
    },
  },
  argTypes: {
    variant: {
      control: { type: "select" },
      options: [
        "invisible",
        "lightest",
        "light",
        "dark",
        "darkest",
      ] satisfies TupleUnion<DividerVariant>,
    },
  },
} satisfies Meta<typeof Divider>;

export default meta;

type Story = StoryObj<typeof Divider>;

export const Default: Story = {};

export const Invisible: Story = {
  args: {
    variant: "invisible",
  },
};

export const Light: Story = {
  args: {
    variant: "light",
  },
};

export const Dark: Story = {
  args: {
    variant: "dark",
  },
};

export const Darkest: Story = {
  args: {
    variant: "darkest",
  },
};
