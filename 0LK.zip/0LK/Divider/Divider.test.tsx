import { render, screen } from "@testing-library/react";

import "@testing-library/jest-dom";
import { Divider, DIVIDER_VARIANTS } from "./Divider";
import styles from "./Divider.module.scss";

describe("Divider Component", () => {
  it("renders correctly", () => {
    render(<Divider />);
    const dividerElement = screen.getByRole("separator");
    expect(dividerElement).toBeInTheDocument();
  });

  it("applies default class when no variant is provided", () => {
    render(<Divider />);
    const dividerElement = screen.getByRole("separator");
    expect(dividerElement).toHaveClass(styles.divider);
  });

  DIVIDER_VARIANTS.forEach((variant) => {
    it(`applies correct class for variant "${variant}"`, () => {
      render(<Divider variant={variant} />);
      const dividerElement = screen.getByRole("separator");
      expect(dividerElement).toHaveClass(styles.divider);
    });
  });

  it("applies additional class names", () => {
    render(<Divider className="additional-class" />);
    const dividerElement = screen.getByRole("separator");
    expect(dividerElement).toHaveClass("additional-class");
  });

  it("passes additional props to the div element", () => {
    render(<Divider data-testid="divider-test" />);
    const dividerElement = screen.getByTestId("divider-test");
    expect(dividerElement).toBeInTheDocument();
  });
});
