import { StoryFn, Meta } from "@storybook/react";
import cn from "classnames";

import landscapeImage from "@/assets/stories/Landscape1920x1080edges32.png";
import landscapeVideo from "@/assets/stories/LandscapeDemoLowPlain.mp4";
import portraitImage from "@/assets/stories/Portrait1080x1920edges32.png";
import portraitVideo from "@/assets/stories/PortraitDemoLowPlain.mp4";
import {
  TooltipIconColor,
  TooltipState,
  TooltipWithIcon,
} from "@/components/TooltipWithIcon/TooltipWithIcon";
import { DemoEditableText } from "@/stories/presentation/DemoEditableText";

import { DynamicMedia } from "./DynamicMedia";
import styles from "./DynamicMedia.stories.module.scss";
import { TooltipLocation } from "./DynamicMedia.utils";

export default {
  title: "Layouts/Dynamic Media",
  component: DynamicMedia,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=10884-61609",
    },
  },
} as Meta<typeof DynamicMedia>;

const DemoDynamicMedia: React.FC<
  React.ComponentProps<typeof DynamicMedia> & {
    noPortrait?: boolean;
    noLandscape?: boolean;
    content?: React.ReactNode;
    contentFooter?: React.ReactNode;
    noTooltip?: boolean;
    noTooltipLandscape?: boolean;
    tooltipInitialState: TooltipState;
  }
> = ({
  noPortrait,
  noLandscape,
  noTooltip,
  noTooltipLandscape,
  content,
  contentFooter,
  ...args
}) => {
  return (
    <DynamicMedia {...args}>
      {!noLandscape && (
        <DynamicMedia.ImageLandscape>
          <img alt="Landscape" src={landscapeImage} />
        </DynamicMedia.ImageLandscape>
      )}
      {!noLandscape && (
        <DynamicMedia.ImageLandscapeDisclaimer>
          {!(noTooltip || noTooltipLandscape) && (
            <DemoEditableText value="Test editable Image Landscape. Some more text to test tooltip wrapping" />
          )}
        </DynamicMedia.ImageLandscapeDisclaimer>
      )}
      {!noLandscape && (
        <DynamicMedia.VideoLandscapeDisclaimer>
          {!(noTooltip || noTooltipLandscape) && (
            <DemoEditableText value="Test editable Video Landscape. Some more text to test tooltip wrapping" />
          )}
        </DynamicMedia.VideoLandscapeDisclaimer>
      )}
      {!noPortrait && (
        <DynamicMedia.ImagePortrait>
          <img alt="L1" src={portraitImage} />
        </DynamicMedia.ImagePortrait>
      )}
      {!noPortrait && (
        <DynamicMedia.ImagePortraitDisclaimer>
          {!noTooltip && (
            <DemoEditableText value="Test editable Image Portrait. Some more text to test tooltip wrapping" />
          )}
        </DynamicMedia.ImagePortraitDisclaimer>
      )}
      {!noPortrait && (
        <DynamicMedia.VideoPortraitDisclaimer>
          {!noTooltip && (
            <DemoEditableText value="Test editable Video Portrait. Some more text to test tooltip wrapping" />
          )}
        </DynamicMedia.VideoPortraitDisclaimer>
      )}
      <DynamicMedia.Content>
        {content && content}
        <TooltipWithIcon
          showPopupOnFocus
          iconColor={TooltipIconColor.ACCENT}
          ariaLabel="tooltip"
          className={cn(
            styles.tooltip,
            styles[
              `${
                args.tooltipLocation === TooltipLocation.BOTTOM_RIGHT ? "bottomRight" : "topRight"
              }TooltipContainer`
            ]
          )}
          pointerPosition={
            args.tooltipLocation === TooltipLocation.BOTTOM_RIGHT
              ? "middle-bottom-right"
              : "middle-top-right"
          }
          addShadow
          initialState={args.tooltipInitialState}
        />
      </DynamicMedia.Content>
      {contentFooter && <DynamicMedia.ContentFooter>{contentFooter}</DynamicMedia.ContentFooter>}
    </DynamicMedia>
  );
};

const FullScreenTemplate: StoryFn<typeof DemoDynamicMedia> = (args) => (
  <div style={{ height: "100vh" }}>
    <DemoDynamicMedia {...args} />
  </div>
);

const FullPortraitOnlyTemplate: StoryFn<typeof DemoDynamicMedia> = (args) => (
  <div style={{ height: "100vh" }}>
    <DemoDynamicMedia noLandscape={true} {...args} />
  </div>
);

const FullLandscapeOnlyTemplate: StoryFn<typeof DemoDynamicMedia> = (args) => (
  <div style={{ height: "100vh" }}>
    <DemoDynamicMedia noPortrait={true} {...args} />
  </div>
);

const InContainerTemplate: StoryFn<typeof DemoDynamicMedia> = (args) => (
  <div style={{ width: "420px", maxWidth: "100%" }}>
    <DemoDynamicMedia {...args} />
  </div>
);

export const FullScreen = FullScreenTemplate.bind({});
FullScreen.args = {
  showAll: false,
  tooltipLocation: TooltipLocation.BOTTOM_RIGHT,
  tooltipInitialState: TooltipState.HARD_OPENED,
  aspectRatio: 0,
};

export const FullScreenNoTooltip = FullScreenTemplate.bind({});
FullScreenNoTooltip.args = {
  showAll: false,
  tooltipLocation: TooltipLocation.BOTTOM_RIGHT,
  tooltipInitialState: TooltipState.HARD_OPENED,
  aspectRatio: 0,
  noTooltip: true,
};

const DemoDynamicMediaPortraitAndLandscapeNoLandscapeToolTipTemplate: React.FC<
  React.ComponentProps<typeof DynamicMedia> & {
    content?: React.ReactNode;
    contentFooter?: React.ReactNode;
    noTooltip?: boolean;
    noTooltipLandscape?: boolean;
    tooltipInitialState: TooltipState;
  }
> = ({ noTooltip, noTooltipLandscape, content, contentFooter, ...args }) => {
  return (
    <DynamicMedia {...args}>
      <DynamicMedia.ImageLandscape>
        <img alt="Landscape" src={landscapeImage} />
      </DynamicMedia.ImageLandscape>
      <DynamicMedia.ImageLandscapeDisclaimer>
        {!(noTooltip || noTooltipLandscape) && (
          <DemoEditableText value="Test editable Image Landscape. Some more text to test tooltip wrapping" />
        )}
      </DynamicMedia.ImageLandscapeDisclaimer>
      <DynamicMedia.VideoLandscapeDisclaimer>
        {!(noTooltip || noTooltipLandscape) && (
          <DemoEditableText value="Test editable Video Landscape. Some more text to test tooltip wrapping" />
        )}
      </DynamicMedia.VideoLandscapeDisclaimer>
      <DynamicMedia.ImagePortrait>
        <img alt="L1" src={portraitImage} />
      </DynamicMedia.ImagePortrait>
      <DynamicMedia.ImagePortraitDisclaimer>
        <DemoEditableText value="Test editable Image Portrait. Some more text to test tooltip wrapping" />
      </DynamicMedia.ImagePortraitDisclaimer>
      <DynamicMedia.VideoPortraitDisclaimer>
        <DemoEditableText value="Test editable Video Portrait. Some more text to test tooltip wrapping" />
      </DynamicMedia.VideoPortraitDisclaimer>
      <DynamicMedia.Content>
        {content && content}
        <TooltipWithIcon
          showPopupOnFocus
          iconColor={TooltipIconColor.ACCENT}
          ariaLabel="tooltip"
          className={cn(
            styles.tooltip,
            styles[
              `${
                args.tooltipLocation === TooltipLocation.BOTTOM_RIGHT ? "bottomRight" : "topRight"
              }TooltipContainer`
            ]
          )}
          pointerPosition={
            args.tooltipLocation === TooltipLocation.BOTTOM_RIGHT
              ? "middle-bottom-right"
              : "middle-top-right"
          }
          addShadow
          initialState={args.tooltipInitialState}
        />
      </DynamicMedia.Content>
      {contentFooter && <DynamicMedia.ContentFooter>{contentFooter}</DynamicMedia.ContentFooter>}
    </DynamicMedia>
  );
};

const PortraitAndLandscapeNoLandscapeToolTipTemplate: StoryFn<typeof DemoDynamicMedia> = (args) => (
  <div style={{ height: "100vh" }}>
    <DemoDynamicMediaPortraitAndLandscapeNoLandscapeToolTipTemplate {...args} />
  </div>
);
export const PortraitAndLandscapeNoLandscapeToolTip =
  PortraitAndLandscapeNoLandscapeToolTipTemplate.bind({});
PortraitAndLandscapeNoLandscapeToolTip.args = {
  showAll: false,
  tooltipLocation: TooltipLocation.BOTTOM_RIGHT,
  tooltipInitialState: TooltipState.HARD_OPENED,
  aspectRatio: 0,
  noTooltip: true,
};

FullScreen.argTypes = {
  minHeightDesktop: {
    type: "number",
  },
  minHeightMobile: {
    type: "number",
  },
  videoLandscape: {
    type: "string",
  },
  videoPortrait: {
    type: "string",
  },
  tooltipLocation: {
    options: [0, 1], // iterator
    mapping: [TooltipLocation.TOP_RIGHT, TooltipLocation.BOTTOM_RIGHT], // values
    control: {
      type: "select",
      labels: ["Top Right", "Bottom Right"],
    },
    toolTipInitialState: TooltipState.HARD_OPENED,
  },
};

export const PortraitOnlyScreen = FullPortraitOnlyTemplate.bind({});
PortraitOnlyScreen.args = FullScreen.args;

export const PortraitOnlyScreenNoToolTip = FullPortraitOnlyTemplate.bind({});
PortraitOnlyScreenNoToolTip.args = { ...FullScreen.args, noTooltip: true };

export const LandscapeOnlyScreen = FullLandscapeOnlyTemplate.bind({});
LandscapeOnlyScreen.args = FullScreen.args;

export const LandscapeOnlyScreenNoLandscapeToolTip = FullLandscapeOnlyTemplate.bind({});
LandscapeOnlyScreenNoLandscapeToolTip.args = {
  ...FullScreen.args,
  noTooltipLandscape: true,
};

export const FullScreenVideo = FullScreenTemplate.bind({});
FullScreenVideo.args = {
  showAll: false,
  tooltipLocation: TooltipLocation.BOTTOM_RIGHT,
  tooltipInitialState: TooltipState.HARD_OPENED,
  aspectRatio: 0,
  videoLandscape: landscapeVideo,
  videoPortrait: portraitVideo,
  showVideoController: true,
};

FullScreenVideo.argTypes = FullScreen.argTypes;

export const FullScreenVideoLinkBroken = FullScreenTemplate.bind({});
FullScreenVideoLinkBroken.args = {
  showAll: false,
  tooltipLocation: TooltipLocation.BOTTOM_RIGHT,
  tooltipInitialState: TooltipState.HARD_OPENED,
  aspectRatio: 0,
  videoLandscape: "404video",
  videoPortrait: "404video",
};

FullScreenVideoLinkBroken.argTypes = FullScreen.argTypes;

export const InContainer4by3 = InContainerTemplate.bind({});
InContainer4by3.args = {
  aspectRatio: 0.75,
  showAll: false,
  tooltipLocation: TooltipLocation.TOP_RIGHT,
  minHeightMobile: 300,
  minHeightDesktop: 300,
};

InContainer4by3.argTypes = {
  ...FullScreen.argTypes,
  aspectRatio: {
    type: "number",
  },
};

export const InContainerSquare = InContainerTemplate.bind({});
InContainerSquare.args = {
  ...InContainer4by3.args,
  aspectRatio: 1,
};

InContainerSquare.argTypes = InContainer4by3.argTypes;
