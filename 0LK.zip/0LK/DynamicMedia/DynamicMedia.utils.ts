export enum TooltipLocation {
  TOP_RIGHT = "topRight",
  BOTTOM_RIGHT = "bottomRight",
}
