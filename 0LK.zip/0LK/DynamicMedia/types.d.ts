import type * as CSS from "csstype";
declare module "csstype" {
  interface Properties {
    "--dynamic-media-min-height-desktop"?: `${number}px`;
    "--dynamic-media-min-height-mobile"?: `${number}px`;
    "--dynamic-media-aspect-ratio"?: `${number}%`;
  }
}
