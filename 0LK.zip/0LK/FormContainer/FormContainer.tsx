import styles from "./FormContainer.module.scss";

export const FormContainer: React.FC<React.PropsWithChildren> = ({ children }) => {
  return <div className={styles.formContainer}>{children}</div>;
};
