import { StoryObj } from "@storybook/react";

import { ThemeVariant } from "@/theming/themingTypes";

import { FormSection } from "./FormSection";
import {
  getDecoratorsWithSection,
  getDefaultDecorators,
  getMockContent,
} from "./FormSection.utils";

export default {
  title: "Layouts/Form Section",
  component: FormSection,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=4904-10751&t=tNTEhczsxHevOmRG-4",
    },
  },
  argTypes: {
    variant: {
      control: { type: "select" },
      options: ["default", "alt"] satisfies ThemeVariant[],
      mapping: ["default", "alt"] satisfies ThemeVariant[],
    },
  },
};

type Story = StoryObj<typeof FormSection>;

export const FormSectionWithoutVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  parameters: { layout: "padded" },
  decorators: getDefaultDecorators(),
};

export const FormSectionWithDefaultVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "default" },
  parameters: { layout: "padded" },
  decorators: getDefaultDecorators(),
};

export const FormSectionWithAltVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "alt" },
  parameters: { layout: "padded" },
  decorators: getDefaultDecorators(),
};

export const FocusedFormSectionWithoutVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent(true)}</FormSection>,
  parameters: {
    layout: "padded",
  },
  decorators: getDefaultDecorators(),
};

export const DefaultSectionWithFormSectionWithoutVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  decorators: getDecoratorsWithSection(),
};

export const DefaultSectionWithDefaultFormSection: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "default" },
  decorators: getDecoratorsWithSection(),
};

export const DefaultSectionWithAltFormSection: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "alt" },
  decorators: getDecoratorsWithSection("default"),
};

export const AltSectionWithFormSectionWithoutVariant: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  decorators: getDecoratorsWithSection("alt"),
};

export const AltSectionWithDefaultFormSection: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "default" },
  decorators: getDecoratorsWithSection("alt"),
};

export const AltSectionWithAltFormSection: Story = {
  render: (args) => <FormSection {...args}>{getMockContent()}</FormSection>,
  args: { variant: "alt" },
  decorators: getDecoratorsWithSection("alt"),
};
