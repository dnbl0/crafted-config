import { render, screen } from "@testing-library/react";

import "@testing-library/jest-dom";
import { FormSection } from "./FormSection";

describe("FormSection Component", () => {
  it("render the component properly", () => {
    render(<FormSection />);
    const formSectionElement = screen.getByTestId("form-section");
    expect(formSectionElement).toHaveClass("formSection");
  });

  it("applies the className prop correctly", () => {
    const className = "custom-class";
    render(<FormSection className={className} />);
    const formSectionElement = screen.getByTestId("form-section");
    expect(formSectionElement).toHaveClass(className);
  });
});
