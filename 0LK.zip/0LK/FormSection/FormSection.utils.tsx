import { StoryFn } from "@storybook/react";

import { ContentBlock } from "@/components/ContentBlock/ContentBlock";
import { ContentBlockInnerContainer } from "@/components/ContentBlockInnerContainer/ContentBlockInnerContainer";
import { FormContainer } from "@/components/FormContainer/FormContainer";
import { DemoEditableText } from "@/stories/presentation/DemoEditableText";
import { ThemeVariant } from "@/theming/themingTypes";

export const getDefaultDecorators = () => [
  (Story: StoryFn) => (
    <FormContainer>
      <Story />
    </FormContainer>
  ),
];

export const getDecoratorsWithSection = (sectionVariant: ThemeVariant = "default") => [
  (Story: StoryFn) => (
    <ContentBlock variant={sectionVariant}>
      <ContentBlockInnerContainer>
        <FormContainer>
          <Story />
        </FormContainer>
      </ContentBlockInnerContainer>
    </ContentBlock>
  ),
];

export const getMockContent = (isFocused = false) => (
  <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
    <h1>This is test text!</h1>
    <DemoEditableText
      value="Focus on me and containers will have focus states"
      isFocused={isFocused}
    />
  </div>
);
