import { Meta, StoryFn } from "@storybook/react";

import { GlobalFooter, type GlobalFooterData } from "./GlobalFooter";

export default {
  title: "Components/Navigation/Global Footer",
  component: GlobalFooter,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=12325-63517",
    },
  },
} as Meta<typeof GlobalFooter>;

const Template: StoryFn<typeof GlobalFooter> = (args) => <GlobalFooter {...args} />;

const sampleData: GlobalFooterData = {
  copyrightText: {
    value: "copyright text goes here",
  },
  details: {
    children: {
      results: [
        {
          link: {
            label: "Lexus Australia Privacy",
            target: "_self",
            url: "https://www.lexus.com.au/smallprint/privacy",
          },
        },
        {
          link: {
            label: "Tems of Use",
            target: null,
            url: "https://www.lexus.com.au/smallprint/terms",
          },
        },
        {
          link: {
            label: "Test Link 3",
            target: "_self",
            url: "http://lexus.com.au",
          },
        },
        {
          link: {
            label: "Test Link 4",
            target: null,
            url: "http://lexus.com.au",
          },
        },
        {
          link: {
            label: "Test Link 5",
            target: null,
            url: "http://lexus.com.au",
          },
        },
      ],
    },
  },
};

export const GlobalFooterWithData = Template.bind({});
GlobalFooterWithData.args = {
  data: sampleData,
};
