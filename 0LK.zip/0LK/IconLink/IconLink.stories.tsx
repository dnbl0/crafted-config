import { Meta, StoryObj } from "@storybook/react";

import { SVGBrochure } from "@/components/SVGIcon/static/SVGBrochure";
import { SVGInfoCircle } from "@/components/SVGIcon/static/SVGInfoCircle";

import { IconLink } from "./index";

const meta = {
  title: "Components/IconLink",
  component: IconLink,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=6898-61855",
    },
  },
  args: {},
} satisfies Meta<typeof IconLink>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    children: "Discover",
    href: "https://lexus.com.au",
    target: "_blank",
  },
};

export const Spaced: Story = {
  args: {
    children: "Discover",
    variant: "spaced",
    href: "https://lexus.com.au",
  },
};

export const IconOnly: Story = {
  args: {
    "aria-label": "link",
  },
};

export const CustomIcon: Story = {
  args: {
    icon: <SVGInfoCircle />,
    children: "Discover",
    href: "https://lexus.com.au",
  },
};

export const Hovered: Story = {
  parameters: {
    pseudo: {
      hover: true,
    },
  },
  args: {
    children: "Discover",
    href: "https://lexus.com.au",
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    children: "Discover",
  },
};

export const IconOnLeft: Story = {
  args: {
    children: "Discover",
    iconPosition: "start",
  },
};

export const IconOnRight: Story = {
  args: {
    children: "Discover",
    iconPosition: "end",
  },
};

export const Large: Story = {
  args: {
    variant: "large",
    children: "Back",
    href: "/",
  },
};

export const Stacked: Story = {
  args: {
    children: "Request a brochure",
    href: "/",
    variant: "stacked",
    icon: <SVGBrochure />,
  },
};
