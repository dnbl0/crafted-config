import { composeStory } from "@storybook/react";
import { render } from "@testing-library/react";

import Meta, { Default as DefaultStory } from "./IconLink.stories";
const Default = composeStory(DefaultStory, Meta);

describe("IconLink", () => {
  it("Renders", () => {
    const { getByText } = render(<Default />);
    getByText("Discover");
  });
});
