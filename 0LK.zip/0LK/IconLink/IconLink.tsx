import cn from "classnames";

import { Box } from "@/components/Box/Box";
import { GenericLink } from "@/components/GenericLink/GenericLink";
import { IconLinkProps } from "@/components/IconLink/IconLink.types";
import { Stack } from "@/components/Stack/Stack";
import { SVGChevronRight } from "@/components/SVGIcon/static/SVGChevronRight";
import { Typography } from "@/components/Typography/Typography";
import { mergeProps } from "@/utils/reactExtensions";

import styles from "./IconLink.module.scss";

/**
 * A component used as a tertiary call-out button.
 *
 * ## Usage
 *
 * ```tsx
 * <IconLink href="#" target="_blank">Link Text</IconLink>
 * ```
 *
 * ## Note
 * "end" and "start" positions will not have any hover state,
 * consumer must ensure to apply some background or other highlight
 */
const IconLink: React.FC<IconLinkProps> = ({
  children,
  icon,
  variant,
  iconPosition,
  className,
  ...rest
}) => {
  let position = "";
  if (variant !== "stacked") {
    position = iconPosition ?? "animated";
  }

  return (
    <GenericLink
      variant="quiet"
      hideExternalIcon
      {...mergeProps(rest, { className: cn([styles.iconLink, className]) })}
    >
      <Box py={variant === "spaced" ? "3xs" : "none"}>
        <Stack
          spacing="4xs"
          className={cn(styles.container, {
            [styles.disabled]: rest.disabled,
            [styles.animated]: position === "animated",
            [styles.large]: variant === "large",
            [styles.stacked]: variant === "stacked",
          })}
          direction={variant === "stacked" ? "column" : "row"}
        >
          {["animated", "start"].includes(position) && (
            <span className={cn(styles.icon, styles.iconLeft)} aria-hidden="true">
              {icon || <SVGChevronRight />}
            </span>
          )}
          {variant === "stacked" && (
            <span className={cn(styles.icon, styles.iconStacked)} aria-hidden="true">
              {icon}
            </span>
          )}
          <Typography
            variant="l1"
            className={variant === "stacked" ? styles.textStacked : styles.text}
          >
            {children}
          </Typography>
          {["animated", "end"].includes(position) && (
            <span className={cn(styles.icon, styles.iconRight)} aria-hidden="true">
              {icon || <SVGChevronRight />}
            </span>
          )}
        </Stack>
      </Box>
    </GenericLink>
  );
};

export { IconLink };
