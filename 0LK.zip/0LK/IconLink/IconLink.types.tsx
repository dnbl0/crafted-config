import { SpanLinkProps } from "../GenericLink/GenericLink.types";

export const ICON_LINK_VARIANTS = ["default", "spaced", "large", "stacked"] as const;
export type IconLinkVariant = (typeof ICON_LINK_VARIANTS)[number];

type Stacked = {
  /**
   * Value for stacked variant
   */
  variant?: "stacked";
  /**
   * No icon position for stacked variant
   */
  iconPosition?: never;
};

type WithIconPosition = {
  /**
   * Default is used to create a table, tile is to be used as rendering in SC.
   */
  variant?: Exclude<IconLinkVariant, "stacked">;

  /**
   * Whether to animate the icon or show it on one side
   * @default "animated"
   *
   * ## Note
   * "end" and "start" positions will not have any hover state,
   * consumer must ensure to apply some background or other highlight
   */
  iconPosition?: "start" | "end" | "animated";
};

export type IconLinkProps = (WithIconPosition | Stacked) & {
  /**
   * The icon to display. Defaults to ChevronRight
   */
  icon?: React.ReactNode;
} & React.HTMLProps<HTMLAnchorElement> &
  SpanLinkProps;
