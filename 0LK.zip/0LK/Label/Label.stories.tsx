import { Meta, StoryObj } from "@storybook/react";

import { Label } from "@/components/Label/Label";
import { DemoEditableText } from "@/stories/presentation/DemoEditableText";

import { LabelProps } from "./Label";

export default {
  title: "Components/Label",
  component: Label,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Lexus-Kit-(Dev-System)?node-id=6898-61519&node-type=frame&t=XpZf0xtpVMl7WZaW-0",
    },
  },
} satisfies Meta<LabelProps>;

type Story = StoryObj<typeof Label>;

export const Default: Story = {
  args: {
    children: "This is a label",
  },
};

export const Editable: Story = {
  args: {
    children: <DemoEditableText key="demo2" value="text component 2" />,
  },
};
