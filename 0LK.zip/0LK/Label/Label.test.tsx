import { composeStories } from "@storybook/react";
import { render } from "@testing-library/react";

import * as stories from "./Label.stories";

const { Default } = composeStories(stories);

test("Label renders", () => {
  const { getAllByText } = render(<Default />);
  const element = getAllByText("This is a label");
  expect(element).not.toBeNull();
});
