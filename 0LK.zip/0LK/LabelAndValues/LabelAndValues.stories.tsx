import { Meta, StoryFn } from "@storybook/react";

import { LabelAndValues } from "@/components/LabelAndValues/LabelAndValues";
import { DemoEditableText } from "@/stories/presentation/DemoEditableText";

import { LabelAndValuesProps } from "./LabelAndValues";

export default {
  title: "Components/Label and Values",
  component: LabelAndValues,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Lexus-Kit-(Dev-System)?node-id=6898-61519&node-type=frame&t=XpZf0xtpVMl7WZaW-0",
    },
  },
} as Meta<LabelAndValuesProps>;

const Template: StoryFn<React.FC<LabelAndValuesProps>> = (args) => <LabelAndValues {...args} />;

export const Default = Template.bind({});
Default.args = {
  label: "This is a title",
  children: ["LBX", "UX", "NX", "RX", "ES"],
  layout: "horizontal",
  spacing: "minimal",
  alignment: "left",
};

export const LeftAlignWithMinimalSpacing = Template.bind({});
LeftAlignWithMinimalSpacing.args = {
  label: "This is a title",
  children: [
    "LBX",
    "UX",
    <DemoEditableText key="demo1" value="text component 1" />,
    <DemoEditableText key="demo2" value="text component 2" />,
    "RX",
    "ES",
  ],
  layout: "vertical",
  spacing: "minimal",
  alignment: "left",
};

export const CenterAlignWithNormalSpacing = Template.bind({});
CenterAlignWithNormalSpacing.args = {
  label: "This is a title",
  children: [
    "Exclusive Offers",
    "Exclusive Events",
    "Ampol Fuel Offer",
    "Service Loan Car",
    "DriveCare",
    "Airport Lounge (pay per use)",
  ],
  layout: "vertical",
  spacing: "normal",
  alignment: "center",
};
