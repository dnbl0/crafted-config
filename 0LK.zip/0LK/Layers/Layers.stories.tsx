import { StoryFn, Meta } from "@storybook/react";

import bgImage from "@/assets/stories/diagnostic-image.jpg";

import { Layers } from "./Layers";
import { Typography } from "../Typography/Typography";

export default {
  title: "Layouts/Layers",
  component: Layers,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?type=design&node-id=6604-15969&mode=design&t=APRBf8koY84mYWBP-4",
    },
  },
} as Meta<typeof Layers>;

const Template: StoryFn<typeof Layers> = (args) => (
  <div style={{ height: "300px", width: "50vw" }}>
    <Layers {...args} />
  </div>
);

const LayersWithSideContentTemplate: StoryFn<typeof Layers> = (args) => (
  <div style={{ display: "flex", flexWrap: "wrap", width: "80vw" }}>
    <div style={{ flex: 1, minWidth: "300px", display: "flex" }}>
      <Layers {...args} />
    </div>
    <div style={{ flex: 1, minWidth: "300px" }}>
      <Typography variant="b1">
        What we try to demo here is if there are other elements sitting along side with Layers
        component and the element has really long content, the Layers component can adjust its
        height to match other elements height. Think about same height layout. In smaller screen,
        they will stack vertically and the Layers component will function like Default stories.
        <br /> <br /> <br /> <br />
        What we try to demo here is if there are other elements sitting along side with Layers
        component and the element has really long content, the Layers component can adjust its
        height to match other elements height. Think about same height layout. In smaller screen,
        they will stack vertically and the Layers component will function like Default stories.
        <br /> <br /> <br /> <br />
        What we try to demo here is if there are other elements sitting along side with Layers
        component and the element has really long content, the Layers component can adjust its
        height to match other elements height. Think about same height layout. In smaller screen,
        they will stack vertically and the Layers component will function like Default stories.
      </Typography>
    </div>
  </div>
);

// Consumers can overlap any element they want with proper position setting, making sure element are not overlap each other in the same grid-area
const LayerChildren = (
  <>
    <div>
      <img src={bgImage} alt="bgImage" />
    </div>
    <div
      style={{
        color: "red",
        display: "grid",
        gridTemplateRows: "1fr 1fr",
        gridTemplateColumns: "1fr 1fr",
      }}
    >
      <div
        style={{
          gridRowStart: 1,
          gridRowEnd: 2,
          gridColumnStart: 1,
          gridColumnEnd: 3,
        }}
      >
        <Typography variant="b1">
          Background image is the first child in Layers component, this is the second child. What we
          want to demo is you can stack elements in z-axis in one grid area. And add some position
          setting to each element to make sure their content are not overlap. Layers component is a
          Grid, here we make another 2x2 Grid and place this element in the first row. We also
          create a 2x2 Grid for the third child, and place it in the second row to make sure even we
          resize screen, their content will not overlap and the Layers component can resize if there
          is not enough space for those child element.
        </Typography>
      </div>
    </div>
    <div
      style={{
        color: "green",
        display: "grid",
        gridTemplateRows: "1fr 1fr",
        gridTemplateColumns: "1fr 1fr",
      }}
    >
      <div
        style={{
          gridRowStart: 2,
          gridRowEnd: 3,
          gridColumnStart: 1,
          gridColumnEnd: 3,
        }}
      >
        <Typography variant="b1">This is the third child in Layers component.</Typography>
      </div>
    </div>
  </>
);

export const Default = Template.bind({});
Default.args = {
  children: LayerChildren,
};

export const LayersWithSideContent = LayersWithSideContentTemplate.bind({});
LayersWithSideContent.args = {
  children: LayerChildren,
};
