import { Meta, StoryObj } from "@storybook/react";
import { useState } from "react";

import { getBorderRadiusProps } from "@/components/BorderRadius/BorderRadius";
import { Stack } from "@/components/Stack/Stack";
import { mergeProps } from "@/utils/reactExtensions";

import { Modal } from "./Modal";
import styles from "./ModalStories.module.scss";
import { longText } from "./storyData";
import { Button } from "../Button/Button";
import { Divider } from "../Divider";
import { SVGCross } from "../SVGIcon/static/SVGCross";
import { Typography } from "../Typography/Typography";

const meta = {
  title: "Layouts/Modal",
  component: Modal,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=10343-93352",
    },
  },
  decorators: [
    function Render(Story, { args }) {
      const [isOpen, setIsOpen] = useState(false);

      return (
        <>
          <Button
            onClick={() => {
              setIsOpen(!isOpen);
            }}
          >
            Open Modal
          </Button>
          <Story args={{ ...args, isOpen, onOpenChange: setIsOpen }} />
        </>
      );
    },
  ],
} satisfies Meta<typeof Modal>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    children: ({ close }) => (
      <div
        {...mergeProps(getBorderRadiusProps("extra-large"), {
          className: styles.modal,
        })}
      >
        <Stack spacing="s" direction="column">
          <div className={styles.headerContainer}>
            <Typography variant="s1">Service summary</Typography>
            <button onClick={close} className={styles.closeButton} aria-label="Close">
              <SVGCross />
            </button>
          </div>

          <div className={styles.modalBody}>
            <Stack spacing="s" direction="column">
              <Divider />
              <Stack spacing="4xs" direction="column">
                <Typography variant="l1">Outstanding Safety Recalls</Typography>
                <Stack justifyContent="space-between" alignItems="center" spacing="3xs">
                  <Typography variant="b1">REC-001667</Typography>
                  <Typography variant="b1">COMPLIMENTARY</Typography>
                </Stack>
              </Stack>

              <Stack spacing="4xs" direction="column">
                <Typography variant="l1">Customer Service Exercise(s)</Typography>
                <Stack justifyContent="space-between" alignItems="center" spacing="3xs">
                  <Typography variant="b1">
                    The front and rear fender liners require replacement to ensure adequate
                    clearance to the moving tyres at the rearward portion.
                  </Typography>
                  <Typography variant="b1">COMPLIMENTARY</Typography>
                </Stack>
              </Stack>

              <Stack spacing="4xs" direction="column">
                <Typography variant="l1">Scheduled service</Typography>
                <Stack justifyContent="space-between" alignItems="center" spacing="3xs">
                  <Typography variant="b1">36 months or 45,000 km</Typography>
                  <Typography variant="b1">$495.00</Typography>
                </Stack>
              </Stack>

              <Stack spacing="4xs" direction="column">
                <Typography variant="l1">Add ons</Typography>
                <Stack justifyContent="space-between" alignItems="center" spacing="3xs">
                  <Typography variant="b1">Life cycle review</Typography>
                  <Typography variant="b1">COMPLIMENTARY</Typography>
                </Stack>
              </Stack>

              <Divider />

              <Stack justifyContent="space-between" alignItems="center" spacing="3xs">
                <Typography variant="s1">Total</Typography>
                <Typography variant="h4">$495.00</Typography>
              </Stack>

              <Typography variant="b2">
                Price includes GST and will not change unless you request changes to the service
                booking.
              </Typography>
            </Stack>
          </div>
        </Stack>
      </div>
    ),
  },
};

export const Overflow: Story = {
  args: {
    children: ({ close }) => (
      <div className={styles.modal}>
        <Stack spacing="s" direction="column">
          <div className={styles.headerContainer}>
            <Typography variant="s1">Service summary</Typography>
            <button onClick={close} className={styles.closeButton} aria-label="Close">
              <SVGCross />
            </button>
          </div>

          <div className={styles.modalBody}>
            <Stack spacing="s" direction="column">
              <Divider />
              <Stack spacing="4xs" direction="column">
                <Typography variant="b1">{longText}</Typography>
              </Stack>
            </Stack>
          </div>
        </Stack>
      </div>
    ),
  },
};

export const Popover: Story = {
  args: {
    children: () => (
      <div className={styles.modal}>
        <Stack spacing="s" direction="column">
          <Typography variant="s2">Your service booking session has expired.</Typography>

          <Typography variant="b1">
            You’ve been inactive for a while. For your security, we’ve ended your session and you’ll
            have to start again to make another booking.
          </Typography>
        </Stack>
      </div>
    ),
    isPopover: true,
  },
};
