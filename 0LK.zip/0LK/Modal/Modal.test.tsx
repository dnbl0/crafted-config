import { composeStory } from "@storybook/react";
import { render, fireEvent, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import Meta, { Default as DefaultStory } from "./Modal.stories";
const Default = composeStory(DefaultStory, Meta);

const user = userEvent.setup();

describe("Modal", () => {
  it("Renders", async () => {
    const { getByRole, queryByRole } = render(<Default />);
    const button = getByRole("button");

    await act(async () => {
      await user.click(button);
    });
    getByRole("dialog");

    const closeButton = getByRole("button", { name: "Close" });
    await act(async () => {
      await user.click(closeButton);
    });

    const dialog = queryByRole("dialog");
    expect(dialog).toBeNull();
  });

  it("Dismissible via keyboard", async () => {
    const { getByRole, queryByRole } = render(<Default />);
    const button = getByRole("button");

    await act(async () => {
      await user.click(button);
    });

    getByRole("dialog");

    fireEvent.keyDown(document.activeElement as Element, { key: "Escape" });

    const dialog = queryByRole("dialog");
    expect(dialog).toBeNull();
  });
});
