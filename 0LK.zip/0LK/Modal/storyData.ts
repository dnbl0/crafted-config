export const longText = `Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae deleniti,
harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit? Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit beatae
deleniti, harum, quod distinctio minima nam perferendis mollitia quia, obcaecati
perspiciatis reprehenderit fugit saepe laborum autem! Ducimus cumque recusandae
odit?`;
