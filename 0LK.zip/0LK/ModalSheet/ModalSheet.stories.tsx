import { Meta, StoryFn } from "@storybook/react";
import { useState } from "react";

import { Box } from "@/components/Box/Box";
import { Button } from "@/components/Button/Button";
import { IconButton } from "@/components/IconButton/IconButton";
import { SVGCross } from "@/components/SVGIcon/static/SVGCross";
import { DemoInvisibleElementWrapper } from "@/stories/presentation/DemoInvisibleElementWrapper";
import { ThemeCanvas, ThemeVariant } from "@/theming/themingTypes";
import { TupleUnion } from "@/types/helpers";

import { ModalSheet } from "./ModalSheet";
import styles from "./ModalSheet.stories.module.scss";

export default {
  title: "Layouts/Modal Sheet",
  component: ModalSheet,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=9569-80789&node-type=frame&m=dev",
    },
    args: {
      canvas: "default",
    },
    argTypes: {
      canvas: {
        control: {
          type: "select",
        },
        options: ["default", "lighter", "darker"] satisfies TupleUnion<ThemeCanvas>,
      },
      overlay: {
        control: { type: "select" },
        options: ["blur", "shadow", "blur and shadow", "undefined"],
        mapping: ["blur", "shadow", "blurShadow", undefined],
      },
      themeVariant: {
        control: { type: "select" },
        options: ["default", "alt"] satisfies ThemeVariant[],
        mapping: ["default", "alt"] satisfies ThemeVariant[],
      },
    },
  },
} satisfies Meta<typeof ModalSheet>;

const DemoChildrenContent: React.FC<{
  handleOnClick: (isOpen: boolean) => void;
  children: React.ReactNode;
}> = ({ handleOnClick, children }) => (
  <div className={styles.dialogContentLandscape}>
    <IconButton
      aria-label="Close"
      data-testid={`lk-iconCloseButton`}
      icon={<SVGCross />}
      onClick={() => handleOnClick(false)}
      variant="bare"
    />
    <Button>First Focusable Element</Button>
    {children}
    <Button onClick={() => handleOnClick(false)}>Close</Button>
  </div>
);
const ModalSheetTemplate: StoryFn<typeof ModalSheet> = (args) => {
  const [isOpen, setIsOpen] = useState(!!args.isOpen);
  const handleOnClick = (isOpen: boolean) => {
    setIsOpen(isOpen);
  };

  return (
    <div style={{ position: "relative" }}>
      <DemoInvisibleElementWrapper>
        <span style={{ fontSize: "32px" }}>This is the parent container</span>
        <Button aria-label="Open ModalSheet" onClick={() => handleOnClick(!isOpen)}>
          Click me to Open ModalSheet
        </Button>
        <span>Scroll down for more content</span>
        <div style={{ height: "1000px" }}></div>
        <div style={{ width: "100%", height: "200px", fontSize: "24px", background: "beige" }}>
          Footer content
        </div>
        <Button> Parent focusable element</Button>
        <ModalSheet
          position={args.position}
          reserveSpace={args.position !== "right" && args.reserveSpace}
          isOpen={isOpen}
          isModal={args.isModal}
          onOpenChange={setIsOpen}
          ariaLabel="modalSheetDemo"
          canvas={args.canvas}
          overlay={args.overlay}
          isDismissable={!!args.isDismissable}
          isAnimationSuppressed={args.isAnimationSuppressed}
          themeVariant={args.themeVariant}
          className={styles.dialogStoryContainer}
        >
          <Box p="s">
            <DemoChildrenContent handleOnClick={handleOnClick}>
              This is the content of modal landscape
            </DemoChildrenContent>
          </Box>
        </ModalSheet>
      </DemoInvisibleElementWrapper>
    </div>
  );
};

export const ModalSheetOpenByDefault = ModalSheetTemplate.bind({});
ModalSheetOpenByDefault.args = {
  isOpen: true,
  themeVariant: "default",
  isAnimationSuppressed: true,
};

export const ModalSheetAsADialog = ModalSheetTemplate.bind({});
ModalSheetAsADialog.args = {
  isModal: false,
  isAnimationSuppressed: true,
  reserveSpace: true,
  themeVariant: "default",
};

export const ModalSheetAsAModalWithOverlay = ModalSheetTemplate.bind({});
ModalSheetAsAModalWithOverlay.args = {
  reserveSpace: false,
  isModal: true,
  overlay: "blur",
  isDismissable: true,
  themeVariant: "default",
  isAnimationSuppressed: true,
};
