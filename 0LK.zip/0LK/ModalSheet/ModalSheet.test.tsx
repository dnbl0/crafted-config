import { composeStory } from "@storybook/react";
import { render, fireEvent, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import Meta, { ModalSheetAsAModalWithOverlay as DefaultStory } from "./ModalSheet.stories";
const Default = composeStory(DefaultStory, Meta);

const user = userEvent.setup();

describe("ModalSheet", () => {
  it("Renders", async () => {
    const { getByRole, queryByRole, getByText } = render(<Default />);
    const button = getByText("Click me to Open ModalSheet");
    await act(async () => {
      await user.click(button);
    });
    getByRole("dialog");

    const dialog = queryByRole("dialog");
    expect(dialog).toBeDefined();
  });

  it("Dismissible via keyboard", async () => {
    const { getByRole, queryByRole, getByText } = render(<Default />);
    const button = getByText("Click me to Open ModalSheet");

    await act(async () => {
      await user.click(button);
    });

    getByRole("dialog");

    fireEvent.keyDown(document.activeElement as Element, { key: "Escape" });

    const dialog = queryByRole("dialog");
    expect(dialog).toBeNull();
  });
});
