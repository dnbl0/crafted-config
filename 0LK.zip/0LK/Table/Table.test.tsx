import "@testing-library/jest-dom";
import { render } from "@testing-library/react";

import { RichText } from "../RichText/RichText";

describe("Table", () => {
  it("should render", () => {
    const html = `
        <table>
          <tbody>
            <tr>
              <td>Hello</td>
            </tr>
          </tbody>
        </table>
    `;
    const { container } = render(<RichText html={html} />);

    expect(container).toBeTruthy();
  });
});
