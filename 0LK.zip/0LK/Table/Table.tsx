import cn from "classnames";
import { useRef } from "react";

import { useIsOverflowing } from "@/hooks/useIsOverflowing";

import styles from "./Table.module.scss";

export type TableProps = {
  /**
   * Table Content
   */
  children: React.ReactNode;
  /**
   * Custom html class
   */
  className?: string;
};

/**
 * Component used to style html table elements in RichText component
 *
 * ## NOT MADE TO BE STANDALONE
 *
 * ## Usage
 *
 * ```tsx
 * <Table>
 *   <table>
 *     <thead>
 *       <tr>
 *         <th>Heading 1</th>
 *       </tr>
 *     </thead>
 *     <tbody>
 *       <tr>
 *         <td>Content 1</td>
 *       </tr>
 *     </tbody>
 *   </table>
 * </Table>
 * ```
 */

export const Table: React.FC<TableProps> = ({ children, className }) => {
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const { canScrollLeft, canScrollRight } = useIsOverflowing({
    scrollContainerRef,
  });

  return (
    <div
      className={cn(
        styles.tableContainer,
        {
          [styles.overflowLeft]: canScrollLeft,
          [styles.overflowRight]: canScrollRight,
          [styles.overflowBoth]: canScrollLeft && canScrollRight,
        },
        className
      )}
      ref={scrollContainerRef}
    >
      <table>{children}</table>
    </div>
  );
};
