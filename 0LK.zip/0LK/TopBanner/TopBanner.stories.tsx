import { Meta, StoryObj } from "@storybook/react";

import { TopBanner } from ".";

const meta = {
  title: "Components/Top Banner",
  component: TopBanner,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=10378-97046",
    },
  },
} satisfies Meta<typeof TopBanner>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: { children: "This is a center aligned non-stick banner" },
};
