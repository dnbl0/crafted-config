import { composeStory } from "@storybook/react";
import { render } from "@testing-library/react";

import Meta, { Default as DefaultStory } from "./TopBanner.stories";
const Default = composeStory(DefaultStory, Meta);

describe("TopBanner", () => {
  it("Renders", () => {
    const { getByText } = render(<Default />);
    getByText("This is a center aligned non-stick banner");
  });
});
