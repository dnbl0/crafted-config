import type { StoryObj, Meta } from "@storybook/react";

import { Cell } from "./Cell";
import styles from "./Cell.stories.module.scss";

export default {
  title: "Components/Cell",
  component: Cell,
  argTypes: {
    hasCellBorderRadius: {
      type: "boolean",
      description: "Add border radius to each cell",
    },
  },
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/design/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?node-id=7854-5304&t=jGlBMYNIjeYCO8ML-4",
    },
  },
} satisfies Meta<typeof Cell>;

const MockCellContent = (
  <div style={{ background: "#BD34FE", color: "#000000" }}>This is a cell content</div>
);

type Story = StoryObj<typeof Cell>;
export const CellWithoutPadding: Story = {
  args: {
    cellPadding: "none",
    className: styles.cellTestStyle,
    children: MockCellContent,
  },
};

export const CellWithPadding: Story = {
  args: {
    cellPadding: "default",
    className: styles.cellTestStyle,
    children: MockCellContent,
  },
};

export const CellWithCellGapAndPadding: Story = {
  args: {
    cellGap: "default",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};

export const CellWithoutCellGapAndPadding: Story = {
  args: {
    cellGap: "none",
    cellPadding: "none",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};

export const CellWithCellGapNoPadding: Story = {
  args: {
    cellGap: "default",
    cellPadding: "none",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};

export const CellWithCellPaddingNoGap: Story = {
  args: {
    cellGap: "none",
    cellPadding: "default",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};

export const CellAsAside: Story = {
  args: {
    component: "aside",
    cellPadding: "none",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};

export const CellAsSection: Story = {
  args: {
    component: "section",
    cellPadding: "none",
    className: styles.cellTestStyle,
    children: (
      <>
        {MockCellContent}
        {MockCellContent}
      </>
    ),
  },
};
