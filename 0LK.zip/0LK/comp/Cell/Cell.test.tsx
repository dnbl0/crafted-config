import { render, screen } from "@testing-library/react";

import { Cell } from "./Cell";
import "@testing-library/jest-dom";

describe("Cell", () => {
  it("should render children correctly", () => {
    render(<Cell>Test Content</Cell>);
    expect(screen.getByText("Test Content")).toBeInTheDocument();
  });

  it("should apply the correct class names based on props", () => {
    const { container } = render(<Cell hasCellBorderRadius />);
    expect(container.firstChild).toHaveClass("stack cell");
  });

  it("should handle additional class names", () => {
    const { container } = render(<Cell className="additional-class" />);
    expect(container.firstChild).toHaveClass("additional-class");
  });
});
