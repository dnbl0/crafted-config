import { Meta, StoryFn } from "@storybook/react";

import { FormTypography, FormTypographyProps } from "./FormTypography";
import { FormContainer } from "../FormContainer/FormContainer";

export default {
  title: "Components/Form Typography",
  component: FormTypography,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/file/a45Y8haw7B34SQ5apG3Jzl/OSB-%26-SLC-(Delivery)?type=design&node-id=3602-7166&mode=design&t=DQJt1LOAmtjAe44u-0",
    },
  },
} as Meta;

const Template: StoryFn<React.FC<FormTypographyProps>> = (args) => (
  <FormContainer>
    <FormTypography {...args} />
  </FormContainer>
);

export const Title = Template.bind({});
Title.args = {
  type: "title",
  text: "This is a title",
};

export const Subtitle = Template.bind({});
Subtitle.args = {
  type: "subtitle",
  text: "This is a sub title",
};

export const Header = Template.bind({});
Header.args = {
  type: "header",
  text: "This is a subtitle that asks user a question. Alot of the time these 2 pieces of text are used in combination.",
};

export const Subheader = Template.bind({});
Subheader.args = {
  type: "sub",
  text: "This is more contextual information or helper text",
};

export const Label = Template.bind({});
Label.args = {
  type: "label",
  text: "This is more contextual information or helper text",
};

export const SubLabel = Template.bind({});
SubLabel.args = {
  type: "subLabel",
  text: "This is more contextual information or helper text",
};

export const WithTooltip = Template.bind({});
WithTooltip.args = {
  type: "label",
  text: "This is more contextual information or helper text. This is more contextual information or helper text.",
  tooltipText: "This is a tooltip",
  pointerPosition: "top-middle",
};
