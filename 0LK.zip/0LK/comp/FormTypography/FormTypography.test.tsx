import { composeStories } from "@storybook/react";
import { render, screen } from "@testing-library/react";

import * as stories from "./FormTypography.stories";

const { Title, Subtitle, Header, Subheader, Label, SubLabel } = composeStories(stories);

test("renders Title", () => {
  render(<Title />);

  const titleByTestId = screen.getByTestId("lk-tg-h2");
  expect(titleByTestId).not.toBeNull();
});

test("renders Subtitle", () => {
  render(<Subtitle />);

  const titleByTestId = screen.getByTestId("lk-tg-h5");
  expect(titleByTestId).not.toBeNull();
});

test("renders Header", () => {
  render(<Header />);

  const headerByTestId = screen.getByTestId("lk-tg-s1");
  expect(headerByTestId).not.toBeNull();
});

test("renders Subheader", () => {
  render(<Subheader />);

  const subHeaderByTestId = screen.getByTestId("lk-tg-b2");
  expect(subHeaderByTestId).not.toBeNull();
});

test("renders Label", () => {
  render(<Label />);

  const labelByTestId = screen.getByTestId("lk-tg-b1");
  expect(labelByTestId).not.toBeNull();
});

test("renders Label2", () => {
  render(<SubLabel />);

  const labelByTestId = screen.getByTestId("lk-tg-l1");
  expect(labelByTestId).not.toBeNull();
});
