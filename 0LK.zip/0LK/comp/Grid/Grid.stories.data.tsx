import { Box } from "@/components/Box/Box";
import {
  CARD_IMAGE_HEADER,
  CARD_IMAGE_HEADER_WITH_TOOLTIP,
  TEXT_AND_HEADING_NO_ICON_LINK,
  TEXT_AND_HEADING_WITH_ICON_LINK,
} from "@/components/Card/Card.stories.data";
import { CardLayouts, CardProps } from "@/components/Card/Card.types";

import { Grid } from "./Grid";
import { Card } from "../Card/Card";

export const CARD = (extraText = "", layout?: CardLayouts) => (
  <Grid.Item>
    <Card
      padding="small"
      layout={layout || "auto"}
      noBackground
      justifyContent={layout === "horizontal" ? "center" : undefined}
    >
      <Card.Top padding="none">{CARD_IMAGE_HEADER}</Card.Top>
      {TEXT_AND_HEADING_WITH_ICON_LINK(extraText)}
    </Card>
  </Grid.Item>
);

export const CARD_NO_ICON_LINK = (extraText = "", layout?: CardLayouts): JSX.Element => (
  <Grid.Item>
    <Card padding="small" layout={layout || "auto"} noBackground>
      <Card.Top padding="none">{CARD_IMAGE_HEADER}</Card.Top>
      {TEXT_AND_HEADING_NO_ICON_LINK(extraText)}
    </Card>
  </Grid.Item>
);

export const THREE_CARDS = (layout?: CardLayouts) => (
  <>
    {CARD("", layout)}
    {CARD(
      "Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. ",
      layout
    )}
    {CARD(
      "Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. ",
      layout
    )}
  </>
);

export const CARD_WITH_TOOLTIP = ({
  extraText,
  layout,
  key,
  totalItems,
  ...rest
}: CardProps & { extraText?: string; key?: React.Key; totalItems?: number }): JSX.Element => (
  <Grid.Item>
    <Card
      padding="small"
      layout={layout || "auto"}
      noBackground
      justifyContent={layout === "horizontal" ? "center" : undefined}
      key={key}
      {...rest}
    >
      <Card.Top padding="none">{CARD_IMAGE_HEADER_WITH_TOOLTIP(String(key))}</Card.Top>
      {totalItems && totalItems > 1 && (
        <Card.Indicator>
          <Box pb="4xs">
            {key != null ? parseInt(key.toString()) + 1 : null}/{totalItems}
          </Box>
        </Card.Indicator>
      )}
      {TEXT_AND_HEADING_WITH_ICON_LINK(extraText)}
    </Card>
  </Grid.Item>
);

export const THREE_CARDS_WITH_TOOLTIP = (layout?: CardLayouts) => (
  <>
    {CARD_WITH_TOOLTIP({ layout })}
    {CARD_WITH_TOOLTIP({
      extraText:
        "Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. ",
      layout,
    })}
    {CARD_WITH_TOOLTIP({
      extraText:
        "Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. Step into the future with confidence as you embrace the seamless blend of bold design and groundbreaking technology in the UX 300e. This revolutionary vehicle epitomizes urban exploration, offering the robust power of an SUV combined with the agile maneuverability of a hatchback—all powered by electrifying innovation. ",
      layout,
    })}
  </>
);

export const FOUR_CARDS = (layout?: CardLayouts) => (
  <>
    {THREE_CARDS(layout)}
    {CARD("", layout)}
  </>
);

export const FOUR_CARDS_WITH_TOOLTIP = (layout?: CardLayouts) => (
  <>
    {THREE_CARDS_WITH_TOOLTIP(layout)}
    {CARD_WITH_TOOLTIP({ layout })}
  </>
);
