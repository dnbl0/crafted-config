import { Meta, StoryObj } from "@storybook/react";

import { ContentBlock } from "@/components/ContentBlock/ContentBlock";
import { ContentBlockInnerContainer } from "@/components/ContentBlockInnerContainer/ContentBlockInnerContainer";
import { Grid } from "@/components/Grid/Grid";
import { GridProps } from "@/components/Grid/Grid.types";
import { DemoSlot } from "@/stories/presentation/DemoSlot";

type GridStoryArgs = {
  noDefaultDecorator: boolean;
} & GridProps;

const meta = {
  title: "layouts/Grid",
  component: Grid,
  parameters: {
    layout: "fullscreen",
    design: {
      type: "figma",
      url: "https://www.figma.com/file/YoHOVEYxZAcqH88L3jXBas/Lexus-%2F-Design-System?type=design&node-id=3776-17406&mode=design&t=PdbYCmnWTVZ4C215-0",
    },
    viewport: {
      defaultViewport: "desktop",
    },
  },
  argTypes: {
    heading: {
      control: { type: "text" },
      description:
        "Optionally include a heading by setting a value. Leave blank to render no heading.",
    },
    showMoreLabel: { type: "string" },
  },
  decorators: [
    (Story, context) =>
      context.args.noDefaultDecorator ? (
        <Story />
      ) : (
        <ContentBlock>
          <ContentBlockInnerContainer width="12col">
            <Story />
          </ContentBlockInnerContainer>
        </ContentBlock>
      ),
  ],
  args: {
    heading: undefined,
  },
} as Meta<GridStoryArgs>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 4 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    heading: "TITLE",
  },
};

export const Mobile: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 4 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    heading: "TITLE",
  },
  parameters: {
    viewport: {
      defaultViewport: "mobile",
    },
  },
};

export const MobileLandscape: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 4 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    heading: "TITLE",
  },
  parameters: {
    viewport: {
      defaultViewport: "mobile",
      defaultOrientation: "landscape",
    },
  },
};

export const NoHeading: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 4 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {},
};

export const ThreeCards: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 3 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    heading: "TITLE",
  },
};

export const CustomComponents: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 3 }, (_, index) => (
        <Grid.Item component="div" key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    heading: "TITLE",
    component: "div",
  },
};

export const TwoColumns: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 3 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    columns: 2,
    heading: "TITLE",
  },
};

export const ThreeColumns: Story = {
  render: (args) => (
    <Grid {...args}>
      {Array.from({ length: 4 }, (_, index) => (
        <Grid.Item key={index}>
          <DemoSlot />
        </Grid.Item>
      ))}
    </Grid>
  ),
  args: {
    columns: 3,
    heading: "TITLE",
  },
};

export const ThreeRows: Story = {
  render: (args) => (
    <Grid {...args}>
      {/* Using a Fragment to show that the component can handle Fragments */}
      <>
        {Array.from({ length: 21 }, (_, index) => (
          <Grid.Item key={index}>
            <DemoSlot />
          </Grid.Item>
        ))}
      </>
    </Grid>
  ),
  args: {
    heading: "TITLE",
    columns: 3,
    rows: 3,
  },
};
