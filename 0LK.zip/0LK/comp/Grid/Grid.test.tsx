import { composeStory } from "@storybook/react";
import { act, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom";

import Meta, { Default as DefaultStory, ThreeRows as ThreeRowsStory } from "./Grid.stories";
const Default = composeStory(DefaultStory, Meta);
const ThreeRows = composeStory(ThreeRowsStory, Meta);

describe("Grid", () => {
  it("When a heading is defined, it renders a heading with the defined text content", () => {
    render(<Default />);
    screen.getByRole("heading", { name: "TITLE" });
  });

  it("Renders a ul by default", () => {
    render(<Default />);
    const gridTagName = screen.getByRole("list").tagName.toLowerCase();

    expect(gridTagName).toBe("ul");
  });

  it.each(["ol", "ul"] as const)("When `component` is %s it renders an %s", (component) => {
    render(<Default component={component} />);
    const gridTagName = screen.getByRole("list").tagName.toLowerCase();

    expect(gridTagName).toBe(component);
  });

  it("Hides the 'Show more' button by default", () => {
    render(<Default />);
    expect(screen.queryByRole("button", { name: "Show more" })).not.toBeInTheDocument();
    expect(screen.getAllByRole("listitem")).toHaveLength(4);
  });

  it("Renders a 'Show more' button When more than three rows of items are defined", async () => {
    render(<ThreeRows />);
    const user = userEvent.setup();

    const statusElement = screen.getByRole("status", { hidden: true });
    const showMoreButton = screen.getByRole("button", { name: "Show more" });

    expect(statusElement.textContent).toBe("Showing 9 of 21 items.");
    expect(screen.getByRole("list").childNodes).toHaveLength(9);

    await act(() => user.click(showMoreButton));
    expect(screen.getByRole("list").childNodes).toHaveLength(18);
    expect(statusElement.textContent).toBe("Showing 18 of 21 items.");

    await act(() => user.click(showMoreButton));
    expect(statusElement.textContent).toBe("Showing 21 of 21 items.");
    expect(showMoreButton).not.toBeInTheDocument();
    expect(screen.queryByRole("status")).toHaveFocus();
  });

  it("When a `showMoreLabel` is defined it is set as the label of the button", () => {
    render(<ThreeRows showMoreLabel="Mock label" />);
    expect(screen.getByRole("button", { name: "Mock label" })).toBeVisible();
  });

  it("Renders defined number of `rows`", () => {
    render(<ThreeRows rows={4} />);
    expect(screen.getAllByRole("listitem")).toHaveLength(12);
  });

  it("Fires `onClickShowMore` when defined", async () => {
    const onClickShowMoreMock = jest.fn();
    render(<ThreeRows onClickShowMore={onClickShowMoreMock} />);
    const user = userEvent.setup();
    const showMoreButton = screen.getByRole("button", { name: "Show more" });

    await act(() => user.click(showMoreButton));

    expect(onClickShowMoreMock).toHaveBeenCalledTimes(1);
  });
});
