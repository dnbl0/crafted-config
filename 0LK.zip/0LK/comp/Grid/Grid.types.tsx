export type GridProps = Required<React.PropsWithChildren> & {
  /**
   * Optionally include a heading by setting a value. Leave blank to render no heading.
   */
  heading?: string;
  /**
   * Define the number of columns, maximum of three.
   *
   * Default: 2
   */
  columns?: 2 | 3;
  /**
   * Set the semantic element of the Grid to the type of list you're using.
   *
   * Default: `"ul"` (unordered list)
   */
  component?: "ul" | "ol" | "div";
  /**
   * Optionally call a function when the 'Show more' button is pressed. This will include
   * the event object as the first argument.
   */
  onClickShowMore?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  /**
   * Define the number of rows to be displayed before a 'Show more' button is rendered. A
   * 'Show more' button will only display if `rows` are defined.
   *
   * Default: 3
   */
  rows?: number;
  /**
   * Customise the label content of the 'Show more' button.
   *
   * Default: "Show more"
   */
  showMoreLabel?: React.ReactNode;
};
