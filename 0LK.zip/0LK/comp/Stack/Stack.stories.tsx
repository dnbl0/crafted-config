import type { Meta, StoryFn } from "@storybook/react";

import { DemoInvisibleElementWrapper } from "@/stories/presentation/DemoInvisibleElementWrapper";
import { DemoLegend, DemoLegendItem } from "@/stories/presentation/DemoLegend";
import { DemoSlot } from "@/stories/presentation/DemoSlot";

import { Stack } from "./Stack";

const meta = {
  title: "Layouts/Stack",
  component: Stack,
  parameters: {
    design: {
      type: "figma",
      url: "https://www.figma.com/file/a45Y8haw7B34SQ5apG3Jzl/OSB-%26-SLC-(Delivery)?type=design&node-id=6515-8054&mode=design&t=p79HAzmZMT3pconn-4",
    },
  },
  args: {
    children: (
      <>
        <DemoSlot />
        <DemoSlot />
        <DemoSlot />
      </>
    ),
  },
} satisfies Meta<typeof Stack>;

export default meta;

const TemplateWithLegend: StoryFn<typeof Stack> = (args) => (
  <>
    <DemoInvisibleElementWrapper>
      <Stack {...args} />
    </DemoInvisibleElementWrapper>
    <DemoLegend description="(font and background colors are not part of component, they used for demo purposes only)">
      <DemoLegendItem description="Gap spacing rendered as part of Stack component">
        <DemoInvisibleElementWrapper legendMode={true} />
      </DemoLegendItem>
      <DemoLegendItem description="Content slot, not part of component">
        <DemoSlot legendMode={true} />
      </DemoLegendItem>
    </DemoLegend>
  </>
);

export const Default = TemplateWithLegend.bind({});
Default.args = {
  spacing: "s",
  alignItems: "center",
};

const Template: StoryFn<typeof Stack> = (args) => (
  <DemoInvisibleElementWrapper>
    <Stack {...args} />
  </DemoInvisibleElementWrapper>
);

export const Column = Template.bind({});
Column.args = {
  spacing: "m",
  direction: "column",
};

export const Alignment = Template.bind({});
Alignment.args = {
  spacing: "m",
  direction: "column",
  alignItems: "center",
  justifyContent: "center",
};
