import { composeStory } from "@storybook/react";
import { render } from "@testing-library/react";

import Meta, { Default as DefaultStory } from "./Stack.stories";
const Default = composeStory(DefaultStory, Meta);

describe("Stack", () => {
  it("Renders", () => {
    const { getAllByText } = render(<Default />);
    const slots = getAllByText("Content children slot");

    expect(slots.length).toBe(3);
  });
});
